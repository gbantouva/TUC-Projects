#include "kernel_pipe.h"
#include "tinyos.h"
#include "kernel_proc.h"

static file_ops pipe_reader_fops = {
        .Open = NULL,
        .Read = pipe_read,
        .Write = NULL,
        .Close = pipe_reader_close
};


static file_ops pipe_writer_fops = {
        .Open = NULL,
        .Read = NULL,
        .Write = pipe_write,
        .Close = pipe_writer_close
};


/**@brief sys_Pipe function.
   Function to create a new pipe. Specifically, a pipe requires two file descriptors,
   one to the read end and one to the write end, while each one is associated with a specific fcb.
   Thus, the function reserves two fcbs and does all the necessary initializations. When
   successful it returns 0. **/

int sys_Pipe(pipe_t* pipe)
{
    /* The two file descriptors are pipe_fid[] and pipe_fcb[]*/
    Fid_t pipe_fid[2];
    FCB* pipe_fcb[2];

    /* Reserve the two fcbs, if not return -1*/
    if(!(FCB_reserve(2, pipe_fid,pipe_fcb)))
        return -1;

    /* Initialization of the pipe */
    pipe->read = pipe_fid[0];
    pipe->write = pipe_fid[1];

    /* New pipe & space allocation */
    PIPE_CB* pipe_cb = (PIPE_CB *)xmalloc(sizeof(PIPE_CB));

    if(pipe_cb==NULL)
    return -1;

    /*Initialization of pipe*/
    pipe_cb->reader=pipe_fcb[0];
    pipe_cb->writer=pipe_fcb[1];

    pipe_cb->has_space=COND_INIT;
    pipe_cb->has_data=COND_INIT;

    pipe_cb->r_position=0;
    pipe_cb->w_position=0;

    pipe_cb->bytes_filled = 0;

    pipe_fcb[0]->streamobj=pipe_cb;
    pipe_fcb[1]->streamobj=pipe_cb;

    pipe_fcb[0]->streamfunc=&pipe_reader_fops;
    pipe_fcb[1]->streamfunc=&pipe_writer_fops;

    return 0;
}



/** @brief pipe_write function
    The fuction writes up from argument buf given to the stream.
    If it is not possible to write any data(full buffer or reader = null for example),
    the thread will block. It returns the bytes copied from buf, or -1 when the function
    isn't successful. **/


int pipe_write(void* pipecb_t, const char *buf, unsigned int size){
    
    PIPE_CB * pipe_cb = (PIPE_CB*) pipecb_t;

    /* Check before continuing with pipe_write */
    if ((pipe_cb == NULL)|| (size < 1) || (buf ==NULL) ){
        return -1;
    }

    if (!pipe_cb->reader || !pipe_cb->writer){
        return -1;
    }

    int * w_position = &pipe_cb->w_position;

    unsigned int bytes_written = 0;  /*Initializing counter for bytes already written*/


    /* Check whether number of bytes written are more than size */
    while(bytes_written < size && pipe_cb->reader!=NULL) {
        /* While buffer is either full or reader==null,
       do kernel broadcast & wait */
        while (pipe_cb-> bytes_filled == PIPE_BUFFER_SIZE && pipe_cb->reader!=NULL) {
            kernel_broadcast(&pipe_cb->has_data);
            kernel_wait(&pipe_cb->has_space, SCHED_PIPE);
        }

        /* We check the reason why while loop stopped */
        /* This can be: */
        /* 1. if pipe_cb->reader==null */
        /* 2. if pipe_cb->bytes=filled!=PIPE_BUFFER_SIZE */
        
        if (pipe_cb->reader==NULL && pipe_cb->bytes_filled==PIPE_BUFFER_SIZE){
            return (int) bytes_written;
        }

        /* space left indicates how many bytes are left to be written */
        int space_left = PIPE_BUFFER_SIZE - pipe_cb->bytes_filled;
        int copy_size = copysize(size,bytes_written,space_left);
        int final_copy_size = finalcopysize(copy_size,PIPE_BUFFER_SIZE,w_position);
        /* copy the arguments */
        memcpy(&(pipe_cb->buffer[*w_position]), &(buf[bytes_written]), final_copy_size);

        bytes_written += final_copy_size;
        pipe_cb->bytes_filled += final_copy_size;
        assert(*w_position < PIPE_BUFFER_SIZE);
        *w_position = (*w_position + final_copy_size) % PIPE_BUFFER_SIZE;
    }
    kernel_broadcast(&pipe_cb->has_data);
    return (int) bytes_written;
}

/** @brief pipe_read function
    The function reads up from stream into the argument buf given. 
    If no data is available, the thread will block, to wait for data.
    It returns the number of bytes copied into buf or if not successful -1. **/

int pipe_read(void* pipecb_t, char *buf, unsigned int size){
    PIPE_CB * pipe_cb = (PIPE_CB*) pipecb_t;


    /* Check before continuing with pipe_write */
    if ((pipe_cb == NULL)|| (size < 1) || (buf ==NULL) ){
        return -1;
    }

    if (!pipe_cb->reader){
        return -1;
    }else if(pipe_cb->bytes_filled==0 && pipe_cb->writer == NULL){ //Isos na vgei i malakia?
        return 0;
    }

    int * r_position = &pipe_cb->r_position;
    unsigned int bytes_read = 0;

    /* Check whether number of bytes written are more than size */
    while(bytes_read < size) {
        /* While buffer is either full or writer==null,
       do kernel broadcast & wait */
        while (pipe_cb->bytes_filled==0 && pipe_cb->writer != NULL) {
            kernel_broadcast(&pipe_cb->has_space);
            kernel_wait(&pipe_cb->has_data, SCHED_PIPE);
        }

        /* We check the reason why while loop stopped */
        /* This can be: */
        /* 1. if pipe_cb->writer==null */
        /* 2. if pipe_cb->bytes=filled!=0*/
        if (pipe_cb->bytes_filled==0 && pipe_cb->writer==NULL){
            return bytes_read;
        }

        /* space left indicates how many bytes are already filled */
        int space_left = pipe_cb->bytes_filled;
        int copy_size = copysize(size,bytes_read,space_left);
        //int copy_size = (size - bytes_read) < space_left ? (int) (size - bytes_read) : space_left;
        int final_copy_size = finalcopysize(copy_size,PIPE_BUFFER_SIZE, r_position);
        //int final_copy_size = copy_size < PIPE_BUFFER_SIZE - *r_position ? copy_size : PIPE_BUFFER_SIZE - *r_position;

        memcpy(&(buf[bytes_read]), &(pipe_cb->buffer[*r_position]), final_copy_size);

        bytes_read += final_copy_size;
        pipe_cb->bytes_filled -= final_copy_size;
        assert(PIPE_BUFFER_SIZE > *r_position );
        *r_position = (*r_position + final_copy_size) % PIPE_BUFFER_SIZE;
        kernel_broadcast(&pipe_cb->has_space);
    }
    kernel_broadcast(&pipe_cb->has_space);
    return bytes_read;
}



/** @brief pipe_writer_close function 
    Implemented almost the same as pipe_writer_close().
    It closes the stream object of a pipe_cb. First, checks if pipe_cb is null or 
    already closed. If so, it returns -1. Otherwise it closes the writer and checks if reader
    is also null in order to free the pipe_cb. **/

int pipe_writer_close(void* _pipecb){

    PIPE_CB * pipe_cb = (PIPE_CB*) _pipecb;

/* If pipe_cb is null or it's already closed, return -1 */ 
    if((pipe_cb==NULL )|| (pipe_cb->writer==NULL)){
        return -1;
    }

    pipe_cb->writer = NULL;

     if(pipe_cb->reader==NULL){
        free(pipe_cb);
        }
     else{
        kernel_broadcast(&pipe_cb->has_data);
        }

    return 0;

}

/** @brief pipe_reader_close function 
    It closes the reader of a pipe_cb. First, it checks if pipe_cb is null 
    or already closed. If so, it returns -1. Otherwise it closes the reader 
    and checks if writer is also null in order to free the pipe_cb. **/

int pipe_reader_close(void* _pipecb){

PIPE_CB * pipe_cb = (PIPE_CB*) _pipecb;

/* If pipe_cb is null or it's already closed, return -1 */
    if((pipe_cb==NULL) || (pipe_cb->reader==NULL)){
        return -1;
    }
    
    pipe_cb->reader=NULL;

    /* If pipe_cb's writer is also null, the free the pipe_cb
    Otherwise, broadcast */
    if(pipe_cb->writer==NULL){
        free(pipe_cb);
    }
    else{
    kernel_broadcast(&pipe_cb->has_space);
    }

    return 0;


}

/** Function copysize 
1. checks the truthful of (size-bytes_written<space_left)
2. returns size=bytes_written if true
3. returns space_left otherwise **/

int copysize(int size,int bytes_written,int space_left){
    if((size - bytes_written) < space_left){
            return (size - bytes_written) ;

        }
        
            return space_left;
}
/** Function finalcopysize 
1. checks the truthful of (copy_size < BUFFER_SIZE - *w_position)
2. returns copysize if true
3. returns BUFFER_SIZE - *w_position otherwise **/

int finalcopysize(int copy_size,int BUFFER_SIZE,int *w_position){
    if(copy_size < BUFFER_SIZE - *w_position){
        return copy_size;
    }
        return BUFFER_SIZE - *w_position;
    }