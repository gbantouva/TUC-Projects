#include "tinyos.h"
#include "kernel_sched.h"
#include "kernel_pipe.h"
#include "kernel_socket.h"
#include "kernel_proc.h"


static file_ops socket_fops = {
        .Open = NULL,
        .Read =  sys_socket_read,
        .Write = sys_socket_write,
        .Close = sys_socket_close
};

/** @brief sys_Socket function.
    It returns a new socket bound on a port by reserving an fcb, creating an SCB
    and by making all the suitable connections between the new socket and the respective fcb. **/

Fid_t sys_Socket(port_t port)
{

    /* Check if port has negatice value or is greater than MAX_PORT and return NOFILE
     Otherwise, continue with the implementation.*/
    if (port < 0 || port > MAX_PORT){
        return NOFILE;
    }

    Fid_t socket_fid[1];
    FCB* socket_fcb[1];

    /* Reserve an FCB for the respective socket and allocate 
    space for a new SCB*/
    if(FCB_reserve(1, socket_fid, socket_fcb)==0)
        return NOFILE; /*no fid available*/

    SCB* socket = (SCB*)xmalloc(sizeof(SCB));

    /* Connections between the socket and the respective fcb*/
    socket_fcb[0]->streamobj = socket;
    socket_fcb[0]->streamfunc = &socket_fops;

    /* Initialize socket*/
    socket->fcb = socket_fcb[0];
    socket->refcount = 0; 

    /* Connect the socket to the port, if port=0 
    then return that there's no port*/
    if(port == 0)
        socket->port = NOPORT;
    else
        socket->port = port;

    socket->type = SOCKET_UNBOUND;

    /*Finally, return the new socket bound on a port*/
    return socket_fid[0];
}


/** @brief sys_Listen function.
    It's used in order to make an unbound socket a listening one. 
    This is achieved by getting the current FCB of sock, doing all the necessary checks and
    by installing the socket to PORT_MAP[] so as to be marked as a SOCKET_LISTENER. **/


int sys_Listen(Fid_t sock)
{
    /* Check if sock is out of bounds */
    if(sock<0 || sock>MAX_FILEID){
        return -1;
    }

    PCB* cur = CURPROC;
    assert(cur!=NULL);

    /* Obtain current FCB of position sock */
    FCB* curfcb =cur->FIDT[sock];
    if(curfcb==NULL){
        return -1;
    }

    /* Assing FCB's streamobj to an instance of socket control block */
    SCB* scb = curfcb->streamobj;

    /* Do all the necessary checks */
    if(scb==NULL){
        return -1;
    }else if(scb->port==NOPORT){
        return -1;
    }else if(PORT_MAP[scb->port]!=NULL){
        return -1;
    }else if(scb->type!=SOCKET_UNBOUND){
        return -1;
    }

    /* Socket is being installed to the PORT_MAP[] */
    PORT_MAP[scb->port] = scb;

    /* Socket is marked as SOCKET_LISTENER */
    scb->type = SOCKET_LISTENER;

    /* Initialize listener_socket fields of the union */
    scb->listener_s.req_available = COND_INIT;
    rlnode_init(&(scb->listener_s.queue), NULL);
    return 0;
}

/** @brief sys_Accept function.
    It waits for a connection to happen. More specifically, it obtains the current SCB of lsock,
    increases refcount and waits for the request. After it checks the port validity, it takes the first connection
    request from the queue and sets creq->admitted = 1. Then it tries to create a peer and initializes the connection,
    signals the connect side and decreases refcount. **/

Fid_t sys_Accept(Fid_t lsock)
{
    /* Check if lsock is out of bounds */
    if (lsock<0 || lsock> MAX_FILEID)
        return  -1;

    /* Obtain current SCB of position lsock */
    FCB* fcb1 = get_fcb(lsock);
    if (fcb1 == NULL || lsock < 0 || lsock > MAX_FILEID ){
        return NOFILE;
    }

    SCB* scb = fcb1->streamobj;

    /* Do all the necessary checks */
    if (scb == NULL || scb->type != SOCKET_LISTENER || PORT_MAP[scb->port] == NULL){
        //SIGNAL ON EVERY RETURN
        return NOFILE;
    }
    /* Increase the refcount and wait for request */
    scb->refcount++;
    while(is_rlist_empty(&(scb->listener_s.queue))&& PORT_MAP[scb->port]!=NULL){
        kernel_wait(&(scb->listener_s.req_available), SCHED_IO);
    }

    /* Check if port map is out of bounds */
    if (PORT_MAP[scb->port] == NULL){

    /* If true decrease the refcount check if it is less than zero, if true free the scb */
        scb->refcount--;
        if (scb->refcount < 0){
        free(scb);
    }
        return NOFILE;
    }

    /* Obtain  the first connection request from the queue */
    rlnode *node  = rlist_pop_front(&(scb->listener_s.queue));
    
    /* Assign node's coonection_request to a coonection_request instance */
    CON_REQ* creq = node->con_req;

    /* Assign coonection_request's peer to a socket_control_block instance ,which will be the client*/
    SCB* scb_cl = creq->peer;

    /* Get the Fid_t of the new socket */
    Fid_t fid_sr = sys_Socket(scb->port);

    /* If false, decrease the refcount */
    if (fid_sr == NOFILE){
        scb->refcount--;
        /* If refcount is less than zero free the scb */
        if (scb->refcount < 0){
        free(scb);
    }   
        /* Else call kernel_signal and if refcount is less than zero free the scb */
        kernel_signal(&(creq->connected_cv));
        if (scb->refcount < 0){
            free(scb);
        }
        return NOFILE;
    }

    /* If true create an scb server */
    
    FCB* fcb2 = get_fcb(fid_sr);
    if (fcb2 == NULL || fid_sr < 0 || fid_sr > MAX_FILEID ){
        return NOFILE;
    }

    SCB* scb_sr = fcb2->streamobj;

    /* Construct two pipes and initialize them */
    PIPE_CB* pipe_cb1 = (PIPE_CB*) xmalloc(sizeof(PIPE_CB));
    PIPE_CB* pipe_cb2 = (PIPE_CB*) xmalloc(sizeof(PIPE_CB));
    
    if(pipe_cb1==NULL)
        return -1;
    if(pipe_cb2==NULL)
        return -1;


    pipe_cb1 = initialize_Pipe(pipe_cb1);
    pipe_cb2 = initialize_Pipe(pipe_cb2);

    /* Do all the necessay connections between the pipes and the SCBs */
    scb_sr->type = SOCKET_PEER;
    scb_sr->peer_s.write_pipe = pipe_cb1;
    scb_sr->peer_s.read_pipe = pipe_cb2;
    scb_sr->peer_s.peer = scb_cl;

    scb_cl->type = SOCKET_PEER;
    scb_cl->peer_s.write_pipe = pipe_cb2;
    scb_cl->peer_s.read_pipe = pipe_cb1;
    scb_cl->peer_s.peer = scb_sr;

    /* Honor the connection request */
    creq->admitted = 1;

    scb->refcount--;
    if (scb->refcount < 0){
        free(scb);
    }
    /* Signal the connect side */
    kernel_signal(&(creq->connected_cv));

    return fid_sr;
}


/** @brief sys_Connect function.
    It creates a connection between a listener and a specific port. To elaborate, it
    obtains the scb with the given Fid_t and allocates space for connection_request as well as 
    initialization. Then, it does the necessary connections and waits until a request is found. Then it 
    wakes up, checks the port(if it's still valid) and adds the requst to the listener's request
    queue. It signals that thre's a request to retrace, waits for the connection to succeed and exits after
    timeout, decreasing refcount. If successful, it returns 0. **/
    
int sys_Connect(Fid_t sock, port_t port, timeout_t timeout)
{

    /* Do all the necessary checks */
    if(sock<0 || sock>MAX_FILEID)
        return -1;

    if(PORT_MAP[port] == NULL || port==NOPORT || port<= 0 || port > MAX_PORT)
        return -1;

    /* Obtain the scb with the given Fid_t */
    SCB* scb = CURPROC->FIDT[sock]->streamobj;

    if(scb==NULL)
        return -1;

    if(scb->type != SOCKET_UNBOUND)
        return -1;

    /* Allocate space for connection_request and do the initializations */
    CON_REQ* con_req = (CON_REQ*) xmalloc(sizeof (CON_REQ));
    con_req->admitted = 0;
    con_req->connected_cv = COND_INIT;
    
    con_req->peer = scb;

    rlnode_init(&(con_req->queue_node), con_req);

    /* Adds the request to the the listener's request queue */
    rlist_push_back(&PORT_MAP[port]->listener_s.queue, &con_req->queue_node);
    assert(is_rlist_empty(&PORT_MAP[port]->listener_s.queue)==0);

    /* Signal that there is a request in order to retrace @accept  */
    kernel_signal(&PORT_MAP[port]->listener_s.req_available);


    /* Wait until connection is made and exit if timeout exceeds.*/
    while(con_req->admitted==0)
    {
        if(kernel_timedwait(&con_req->connected_cv, SCHED_PIPE, timeout)==0)
            return -1;
    }


    scb->refcount--;


    return 0;
}

/** @brief sys_ShutDown function.
    It shuts down one direction of the socket communication same way as in pipes.
    Elaborating, it gets the fcb of the given sock, creates an SCB* scb to be assigned to the sock;s
    fcb->streamobj and does checks. If successful, it checks for the case of shutdown and
    closes the necessary functions. **/

int sys_ShutDown(Fid_t sock, shutdown_mode how)
{
    /* Check if sock is out of bounds */
    if(sock<0 || sock>MAX_FILEID)
        return -1;

    /* Get the FCB of the sock and check again */
    FCB* fcb = get_fcb(sock);
    if (fcb == NULL || sock < 0 || sock > MAX_FILEID ){
        return -1;
    }
    /* Create an scb and assign to the sock's fcb->streamobj */
    SCB* scb = fcb->streamobj;

    /* Check if scb is null or it's type is SOCKET_PEER. If true, then return -1 */
    if(scb==NULL)
        return -1;

    if(scb->type!=SOCKET_PEER)
        return -1;

    /* Cases for shutting down */
    switch (how) {
        case SHUTDOWN_READ:
            pipe_reader_close(scb->peer_s.read_pipe);
            scb->peer_s.read_pipe = NULL;
            break;
        case SHUTDOWN_WRITE:
            pipe_writer_close(scb->peer_s.write_pipe);
            scb->peer_s.write_pipe = NULL;
            break;
        case SHUTDOWN_BOTH:
            pipe_writer_close(scb->peer_s.write_pipe);
            pipe_reader_close(scb->peer_s.read_pipe);
            scb->peer_s.write_pipe = NULL;
            scb->peer_s.read_pipe = NULL;
            break;
        default:
            break;
    }
    return 0;
}

/** @brief sys_socket_read function.
    It creates an SCB* scb by given argument, checks suitably and returns pipe_read.
    It's associated with the Read end of the argument socket. **/

int sys_socket_read(void* scb_p, char *buf, unsigned int size){

    SCB * scb = (SCB *) scb_p;
    if (scb_p == NULL || size<1 || buf==NULL || scb->type != SOCKET_PEER || scb->peer_s.read_pipe == NULL|| (scb->fcb ==NULL)){
        return -1;
    }
    PIPE_CB* pipe_cb = scb->peer_s.read_pipe;
    return pipe_read(pipe_cb, buf, size);
    
}
/** @brief sys_socket_write function.
    It creates an SCB* scb by given argument, checks suitably and returns pipe_write.
    It's associated with the Write end of the argument socket. **/

int sys_socket_write(void* scb_p, const char *buf, unsigned int size){
    SCB * scb = (SCB *) scb_p;
    if (scb_p == NULL || size<1 || buf==NULL || scb->type != SOCKET_PEER || scb->peer_s.write_pipe == NULL||(scb->fcb ==NULL)){
        return -1;
    }
    PIPE_CB* pipe_cb = scb->peer_s.write_pipe;
    return pipe_write(pipe_cb, buf, size);
}

/** @brief sys_socket_close function.
    It closes a socket depending on it's type. Specifically, it checks if argument is null, then return -1
    otherwise if socket's type is    SOCKET_PEER     ---> a peer socket id being detached from it's pipes
                                     SOCKET_LISTENER ---> the listener clears it's queue list and broadcoasts when closed
                                     ANY OTHER CASE  ---> RESETS THE port_map[]

    Then, refcount is being decremented and scb->refcount is checked. 
    If it's less or equal to zero, the scb is being freed. **/

int sys_socket_close(void* scb_p){

    /* If argument is null, return -1 */
    if(scb_p==NULL)
        return -1;

    SCB * scb = (SCB *) scb_p;

    /* Depending on socket's type, it procedures to socket close */ 
    /* It could be also implemented with a switch case function */ 

    /* SOCKET_PEER */
    if(scb->type == SOCKET_PEER){
       
        pipe_writer_close(scb->peer_s.write_pipe);
        pipe_reader_close(scb->peer_s.read_pipe);
    }

    /* SOCKET_LISTENER */
    else if(scb->type == SOCKET_LISTENER){

        while(!is_rlist_empty(&scb->listener_s.queue)){
            
            rlnode* node = rlist_pop_front(&scb->listener_s.queue);
            free(node->con_req);
        }

    /* ANY OTHER CASE */
    PORT_MAP[scb->port]=NULL;
    kernel_broadcast(&scb->listener_s.req_available);

    }

    /* The scb's refcount is decremented by one */
    scb->refcount --;

    /* Check if refcount <=0 and the free the respective scb */
    if (scb->refcount < 0){
        free(scb);
    }
    return 0;
}

/** @brief initialize_Pipe function
    Function with the same implementation as sys_Pipe() but returns 
    a PIPE_CB*. It's function is to create and initialize a pipe. **/

PIPE_CB* initialize_Pipe(PIPE_CB* pipe_cb){

    FCB * fcb[2];

    pipe_cb->reader=fcb[0];
    pipe_cb->writer=fcb[1];

    pipe_cb->has_space=COND_INIT;
    pipe_cb->has_data=COND_INIT;

    pipe_cb->r_position=0;
    pipe_cb->w_position=0;


    pipe_cb->bytes_filled = 0;

    return pipe_cb;
}