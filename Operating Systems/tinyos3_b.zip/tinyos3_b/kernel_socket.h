#ifndef TINYOS3_KERNEL_SOCKET_H
#define TINYOS3_KERNEL_SOCKET_H

#include "tinyos.h"
#include "kernel_sched.h"
#include "kernel_pipe.h"

typedef struct socket_control_block SCB;

typedef enum socket_type_e {
    SOCKET_LISTENER,    /* The PID is free and available */
    SOCKET_UNBOUND,     /*The PID is given to a process */
    SOCKET_PEER         /*The PID is held by a zombie */
} socket_type;

typedef struct unbound_socket {
    rlnode unbound_s;
}unbound_socket;

typedef struct listener_socket{
    rlnode queue;
    CondVar req_available;
}listener_socket;

typedef struct peer_socket {
    SCB* peer;
    PIPE_CB* write_pipe;
    PIPE_CB* read_pipe;
}peer_socket;

typedef struct socket_control_block{
    uint refcount;
    FCB* fcb;
    socket_type type;
    port_t port;

    union {
        unbound_socket unbound_s;
        listener_socket listener_s;
        peer_socket peer_s;
    };
} SCB;

typedef struct connection_request{
    int admitted;
    SCB* peer;

    CondVar connected_cv;
    rlnode queue_node;
} CON_REQ;

SCB * PORT_MAP[MAX_PORT + 1] = { NULL };

Fid_t sys_Socket(port_t port);
Fid_t sys_Accept(Fid_t lsock);

int sys_Listen(Fid_t sock);

int sys_Connect(Fid_t sock, port_t port, timeout_t timeout);

int sys_ShutDown(Fid_t sock, shutdown_mode how);

int sys_socket_read(void* socket_cb, char * buffer, unsigned int n);

int sys_socket_write(void* socket_cb, const char *buffer, unsigned int n);

int sys_socket_close(void * socket_cb);

PIPE_CB* initialize_Pipe(PIPE_CB* pipe_cb);


#endif //TINYOS3_KERNEL_SOCKET_H

