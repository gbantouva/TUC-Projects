#include "tinyos.h"
#include "kernel_sched.h"
#include "kernel_proc.h"
#include "kernel_cc.h"
#include "kernel_streams.h"

/**
  @brief Create a new thread in the current process.
  */
Tid_t sys_CreateThread(Task task, int argl, void* args)
{
  if (task==NULL){
    return NOTHREAD;
  }

  PTCB* ptcb;
  TCB* tcb = spawn_thread(CURPROC, start_new_thread); 	// initialize a new tcb		
  ptcb = (PTCB*)xmalloc(sizeof(PTCB));			// allocate space


  /* setting/initializing the attributes */
  ptcb->task=task;
  ptcb->argl=argl;
  ptcb->args=args;
  ptcb->exitval = -1;
  ptcb->exited=0;
  ptcb->detached=0;
  ptcb->exit_cv=COND_INIT;
  ptcb->refcount=0;
 
  rlnode_init(&ptcb->ptcb_list_node, ptcb);			// initialize the ptcb node

  /* making connections between ptcb and tcb */
  ptcb->tcb = tcb;
  tcb->ptcb = ptcb;

  /* add new ptcb node to the ptcb list */
  rlist_push_back(& CURPROC-> ptcb_list, & ptcb->ptcb_list_node);


  CURPROC->thread_count++;
  wakeup(tcb);
  return (Tid_t) ptcb;
}

/**
  @brief Return the Tid of the current thread.
 */
Tid_t sys_ThreadSelf()
{
	return (Tid_t) cur_thread()->ptcb;
}

/**
  @brief Join the given thread.
  */
int sys_ThreadJoin(Tid_t tid, int* exitval)
{
    rlnode* list= &CURPROC->ptcb_list;			// getting the list with all ptcbs
    rlnode* node = rlist_find(list, (PTCB *) tid, NULL); 	// approach ptcb with wanted tid

    if (node == NULL){    					// not found
        return -1;
    }
    PTCB* ptcb = node->ptcb;

    if(ptcb == NULL ){						// don't exist
        return -1;
    }else if(ptcb->detached!=0) {				// ptcb is detached, thus it is not joinable
        return -1;
    }else if(tid == sys_ThreadSelf()){			// searching for ourselves
      return -1;
    }
    ptcb->refcount ++;						// if found, refcount is increased

    /* wait until it is exited or detached */ 
    while(ptcb->exited==0 && ptcb->detached==0){
        kernel_wait(& ptcb->exit_cv, SCHED_USER);
    }
    ptcb->refcount --;						// decrease counter, since we are not waiting
    if (ptcb->detached!=0){ 					// check if thread was detached
       return -1;	    					// if yes, return -1, because it cannot be joined
    }
    if (exitval!=0){
      *exitval = ptcb->exitval;
    }
    if(ptcb->refcount == 0){					// no one is waiting
      rlist_remove(& ptcb->ptcb_list_node);			// clear list
      free(ptcb);
    }
      return 0;
}

/**
  @brief Detach the given thread.
  */
int sys_ThreadDetach(Tid_t tid)
{
  rlnode* list= &CURPROC->ptcb_list;				//getting the list with all ptcbs
  rlnode* node = rlist_find(list, (PTCB *) tid, NULL);	// getting the wanted ptcb
  if(node==NULL || node->ptcb->exited == 1){			// if ptcb not found || it is exited
        return -1;
    }
  node->ptcb->detached = 1;					// set detached==1 
  kernel_broadcast(& node->ptcb->exit_cv); 			// waking up the threads that are waiting
  return 0;
}

/**
  @brief Terminate the current thread.
  */
void sys_ThreadExit(int exitval)
{ 
    PTCB* ptcb = (PTCB*) cur_thread()->ptcb; 			/* Find current PTCB */
    ptcb->exitval = exitval;
    ptcb->exited = 1;
    CURPROC->thread_count--;
    kernel_broadcast(&ptcb->exit_cv);      			 // The condition variable exit_cv contains all the threads 
                                           			 // waiting the current PTCB to finish. When kernel_broadcast
                                          			 // is called, the waiting threads wake up.
    	
    if(CURPROC->thread_count == 0) {        			 // If we are at the last thread of the PCB, exit starts
        if (get_pid(CURPROC) != 1) {        			 // We must check if the current process isn't the initial


            /* Reparent any children of the exiting process to the
               initial task */
            PCB *initpcb = get_pcb(1);
            while (!is_rlist_empty(&CURPROC->children_list)) {
                rlnode *child = rlist_pop_front(&CURPROC->children_list);
                child->pcb->parent = initpcb;
                rlist_push_front(&initpcb->children_list, child);
            }

            /* Add exited children to the initial task's exited list
               and signal the initial task */
            if (!is_rlist_empty(&CURPROC->exited_list)) {
                rlist_append(&initpcb->exited_list, &CURPROC->exited_list);
                kernel_broadcast(&initpcb->child_exit);
            }

            /* Put me into my parent's exited list */
            rlist_push_front(&CURPROC->parent->exited_list, &CURPROC->exited_node);
            kernel_broadcast(&CURPROC->parent->child_exit);

            }

        assert(is_rlist_empty(&CURPROC->children_list));
        assert(is_rlist_empty(&CURPROC->exited_list));


        /*
          Do all the other cleanup we want here, close files etc.
         */

        /* Release the args data */
        if (CURPROC->args) {
            free(CURPROC->args);
            CURPROC->args = NULL;
        }

        /* Clean up FIDT */
        for (int i = 0; i < MAX_FILEID; i++) {
            if (CURPROC->FIDT[i] != NULL) {
                FCB_decref(CURPROC->FIDT[i]);
                CURPROC->FIDT[i] = NULL;
            }
        }

    }

    /* Disconnect my main_thread */
    CURPROC->main_thread = NULL;

    /* Now, mark the process as exited. */
    CURPROC->pstate = ZOMBIE;

    /* Bye-bye cruel world */
    kernel_sleep(EXITED, SCHED_USER);
   
}

 
