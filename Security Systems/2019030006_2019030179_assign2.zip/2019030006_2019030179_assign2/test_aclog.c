

#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

void performTest(const char *filename, const char *data, size_t dataSize) {
    FILE *file = fopen(filename, "w+");
    if (file == NULL) {
        perror("fopen error");
    } else {
        fwrite(data, 1, dataSize, file);
        fclose(file);
    }
}

int main() {
    int i,j;
    size_t bytes;
    FILE *file;
    char filenames[10][7] = {"file_0", "file_1", 
            "file_2", "file_3", "file_4",
            "file_5", "file_6", "file_7",         
            "file_8", "file_9"};

    /* Test cases */

    // Write to multiple files


    for (i = 0; i < 10; i++) {
        performTest(filenames[i], filenames[i], strlen(filenames[i]));
    }

    // Write to a file and append
    performTest("testFile.txt", "test\n", 5);
    performTest("testFile.txt", "tasdf", 5);

    // Delete contents of a file
    performTest("testFile.txt", "", 0);

    // Write to a file with different data
    performTest("anotherFile.txt", "Hello, World!", 13);

    // Write to a file with binary data
    char binaryData[] = {0x48, 0x65, 0x6C, 0x6C, 0x6F}; // "Hello"
    performTest("binaryFile.bin", binaryData, sizeof(binaryData));
   
	
	for (i = 0; i < 10; i++) {
	    chmod(filenames[i % 5], S_ISUID);
	    performTest(filenames[i], filenames[i], strlen(filenames[i]));

	    chmod(filenames[i], S_IRUSR);
	    performTest(filenames[i], filenames[i], strlen(filenames[i]));
	}
	
    return 0;
}
