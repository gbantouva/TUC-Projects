#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>

struct Entry {
    int uid;
    int access_type;
    int action_denied;
    char *date;
    char *time;
    char *file;
    char *fingerprint;
    struct Entry *next;
};

struct List {
    struct Entry *head;
};

void initializeList(struct List *list) {
    list->head = NULL;
}

void freeList(struct List *list) {
    struct Entry *current = list->head;
    while (current != NULL) {
        struct Entry *temp = current;
        current = current->next;
        free(temp->file);
        free(temp->date);
        free(temp->time);
        free(temp->fingerprint);
        free(temp);
    }
}

void insertEntry(struct List *list, int uid, const char *filename, const char *time, const char *date,
                 int access_type, int action_denied, const char *hash) {
    struct Entry *newEntry = (struct Entry *)malloc(sizeof(struct Entry));
    if (!newEntry) {
        perror("Error allocating memory");
        exit(EXIT_FAILURE);
    }

    newEntry->uid = uid;
    newEntry->file = strdup(filename);
    newEntry->date = strdup(date);
    newEntry->time = strdup(time);
    newEntry->access_type = access_type;
    newEntry->action_denied = action_denied;
    newEntry->fingerprint = strdup(hash);

    newEntry->next = list->head;
    list->head = newEntry;
}

void printUnauthorizedUsers(const int *unauthorized, int m_count) {
    if (!m_count) {
        printf("There aren't any unauthorized users.\n");
    } else {
        printf("Unauthorized user:\n");
        for (int i = 0; i < m_count; i++) {
            printf("id: %d\n", unauthorized[i]);
        }
    }
}

void listUnauthorizedUsers(const struct List *list) {
    int unauthorized[256];
    int m_count = 0;

    struct Entry *prev = list->head;

    while (prev != NULL) {
        int count = 0;
        struct Entry *curr = prev;

        while (curr != NULL) {
            if ((curr->uid == prev->uid) && (curr->action_denied == 1))
                count++;

            curr = curr->next;
        }

        if (count >= 7) {
            int in_list = 0;

            for (int i = 0; i < m_count; i++) {
                if (unauthorized[i] == prev->uid)
                    in_list = -1;
            }

            if (in_list == 0) {
                unauthorized[m_count] = prev->uid;
                m_count++;
            }
        }

        prev = prev->next;
    }

    printUnauthorizedUsers(unauthorized, m_count);
}

void printModifications(const int *modificants, const int *attempts, int mods_count) {
    if (!mods_count) {
        printf("There aren't any modifications for this file.\n");
    } else {
        for (int i = 0; i < mods_count; i++) {
            printf("User %d modified %d times\n", modificants[i], attempts[i]);
        }
    }
}

void listModifications(const struct List *list, const char *targetFile) {
    int modificants[256];
    int attempts[256];
    int mods_count = 0;

    struct Entry *curr = list->head;

    while (curr != NULL) {
        if (strcmp(curr->file, targetFile) == 0) {
            int in_list = 0;

            for (int i = 0; i < mods_count; i++) {
                if (modificants[i] == curr->uid) {
                    attempts[i] += 1;
                    in_list = 1;
                }
            }

            if (in_list == 0) {
                modificants[mods_count] = curr->uid;
                attempts[mods_count] = 1;
                mods_count++;
            }
        }
        curr = curr->next;
    }

    printModifications(modificants, attempts, mods_count);
}

void usage(void) {
    printf("\n"
           "usage:\n"
           "\t./monitor \n"
           "Options:\n"
           "-m, Prints malicious users\n"
           "-i <filename>, Prints table of users that modified "
           "the file <filename> and the number of modifications\n"
           "-h, Help message\n\n");
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
    int ch;
    FILE *logFile;

    if (argc < 2)
        usage();

    logFile = fopen("file_logging.log", "r");
    if (logFile == NULL) {
        perror("Error opening log file");
        exit(EXIT_FAILURE);
    }

    struct List logList;
    initializeList(&logList);

    char *line = NULL;
    size_t lineLength = 0;
    ssize_t readLength;

    while ((readLength = getline(&line, &lineLength, logFile)) != -1) {
        char *str[7];
        char *strToken;
        strToken = strtok(line, " ");
        int j = 0;

        while (strToken != NULL) {
            str[j] = strToken;
            strToken = strtok(NULL, " ");
            j++;
        }

        insertEntry(&logList, atoi(str[0]), str[1], str[2], str[3], atoi(str[4]), atoi(str[5]), str[6]);
    }

    while ((ch = getopt(argc, argv, "hi:m")) != -1) {
        switch (ch) {
        case 'i':
            listModifications(&logList, optarg);
            break;
        case 'm':
            listUnauthorizedUsers(&logList);
            break;
        default:
            usage();
        }
    }

    freeList(&logList);
    fclose(logFile);

    argc -= optind;
    argv += optind;

    return 0;
}
