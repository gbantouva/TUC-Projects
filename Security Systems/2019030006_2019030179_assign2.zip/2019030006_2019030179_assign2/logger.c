#define _GNU_SOURCE

#include <time.h>
#include <stdio.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <openssl/md5.h>
#include <openssl/evp.h>
#include <errno.h>
#include <fcntl.h>

void generateHash(unsigned char *hash, unsigned char *data, size_t len) {
    EVP_MD_CTX *mdContext;

    mdContext = EVP_MD_CTX_new();
    EVP_DigestInit_ex(mdContext, EVP_md5(), NULL);
    EVP_DigestUpdate(mdContext, data, len);
    EVP_DigestFinal_ex(mdContext, hash, NULL);
    EVP_MD_CTX_free(mdContext);
}

#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

void log_print(int uid, int access_t, int access_d, const char *path, struct tm *ti, unsigned char *hash) {
    int logf = open("file_logging.log", O_WRONLY | O_APPEND | O_CREAT, 0644);

    if (logf == -1) {
        perror("Error opening log file");
        return;
    }

    FILE *logFile = fdopen(logf, "a");
    if (!logFile) {
        perror("Error opening file stream");
        close(logf);
        return;
    }

    fprintf(logFile, "%d %s %d-%d-%d %d:%d:%d %d %d ", uid, path, ti->tm_mday, ti->tm_mon + 1, ti->tm_year + 1900,
            ti->tm_hour, ti->tm_min, ti->tm_sec, access_t, access_d);

    // Print the hash
    for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
        fprintf(logFile, "%02x", hash[i]);
    }

    fprintf(logFile, "\n");

    fclose(logFile);
}


void addUser(int f, const char *path, int access_t, int action_d) {
    char output[512];
    int logf = open("file_logging.log", O_WRONLY | O_APPEND | O_CREAT, S_IRUSR | S_IWUSR);

    if (logf == -1) {
        perror("Error opening log file");
        return;
    }

    time_t t;
    struct tm *ti;
    time(&t);
    ti = localtime(&t);

    unsigned char hash[MD5_DIGEST_LENGTH*2+1];
    unsigned char c[MD5_DIGEST_LENGTH];
  
    if (f != -1) {
        EVP_MD_CTX *mdContext;
        ssize_t bytes;
        unsigned char *data = malloc(256);

        if (data == NULL) {
            perror("Memory allocation failed");
            close(logf);
            return;
        }
        
        mdContext = EVP_MD_CTX_new();
        EVP_DigestInit_ex(mdContext, EVP_md5(), NULL);

        bytes = read(f, data, 256);
        if (bytes > 0) {
            while (bytes > 0) {
                EVP_DigestUpdate(mdContext, data, bytes);
                bytes = read(f, data, 256);
            }

            EVP_DigestFinal_ex(mdContext, c, NULL);
            hash[MD5_DIGEST_LENGTH * 2]= '\0' ;
       
        } else if (bytes == 0) {
            EVP_DigestFinal_ex(mdContext, c, NULL);
            hash[MD5_DIGEST_LENGTH * 2]= '\0' ;
        } else {
            hash[0]='\0';
        }

        free(data);
        EVP_MD_CTX_free(mdContext);
    } else {
        memcpy(hash, "000000000000000000", MD5_DIGEST_LENGTH * 2);

    }

    sprintf(output, "%d %s %d:%d:%d %d/%d/%d %d %d %s\n", getuid(), path, ti->tm_hour, ti->tm_min, ti->tm_sec,
            ti->tm_year + 1900, ti->tm_mon + 1, ti->tm_mday, access_t, action_d, hash);

    write(logf, output, strlen(output));
    fprintf(stderr, "addUser called: %s\n", path);

    close(logf);
}

FILE *fopen(const char *path, const char *mode) {
    int action = 0;
    FILE *original_fopen_ret;
    FILE *(*original_fopen)(const char*, const char*);

    original_fopen = dlsym(RTLD_NEXT, "fopen");
    original_fopen_ret = (*original_fopen)(path, mode);

    if (original_fopen_ret == NULL) {
        perror("ERROR opening file");
        fprintf(stderr, "File path: %s\n", path);
    } else {
        int fno = fileno(original_fopen_ret);
        struct stat buffer;
        int actype = (stat(path, &buffer) == 0) ? 1 : 0;

        if (actype == 1 && access(path, R_OK) != 0) {
            perror("ERROR checking file read permission");
            fprintf(stdout, "HAVE NO PERMISSION TO READ FILE!\n");
            action = 1;
        }

        addUser(fno, path, actype, action);
    }

    return original_fopen_ret;
}



size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream) {
    int action = 0;
    size_t original_fwrite_ret;
    size_t (*original_fwrite)(const void *, size_t, size_t, FILE *);

    original_fwrite = dlsym(RTLD_NEXT, "fwrite");
    original_fwrite_ret = (*original_fwrite)(ptr, size, nmemb, stream);

    if (original_fwrite_ret < nmemb) {
        perror("ERROR writing to file");
        if (errno == EACCES || errno == EPERM) {
            fprintf(stdout, "HAVE NO PERMISSION TO WRITE TO FILE!\n");
            action = 1;
        }
    }

    int fno;
    char file_name[1024];
    char p[1024];
    size_t n;

        fno = fileno(stream);
        sprintf(p, "/proc/self/fd/%d", fno);
        n = readlink(p, file_name, 1024);
        if (n < 0) {
            perror("Failed to read link");
            exit(1);
        }
        file_name[n] = '\0';

        char *name = basename(file_name);
        int actype = (nmemb == 0) ? 3 : 2;

        addUser(fno, name, actype, action);

    return original_fwrite_ret;
}
