# Security Systems - LAB B 

## Students:

Maria Stephanaki 2019030179

Georgia Bantouva 2019030006

## 
How to Run:

make clean
make all
make run

./acmonitor -m to print malicious users (if any)
./acmonitor -i <filename> to print users that modified a file given and the number of modifications
./acmonitor -h to print the help message

