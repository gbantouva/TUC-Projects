#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>


/* 
Function to compute key a^b mod p
*/
long long int compute_key(long long int a, long long int b, long long int p){
    return ((( long long int)pow(a, b))%p);
}

/*
Function to check if a number n is prime. 
It returns 1 if it's prime, 0 if it isn't.
*/
int isPrime(long long int n) {
    if (n <=1)
        return 0;
    else if (n <= 3) 
        return 1;               // 2 and 3 are prime numbers
    else if (n%2==0 || n%3==0) 
        return 0;               // check if number is divisible by 2 or 3
    else {
        long long int i;
        for (i=5; i*i<=n; i+=6) {
            if (n % i == 0 || n%(i + 2) == 0) 
                return 0;
        }
        return 1; 
    }
}

/*
Function to check if a number g is a primitive root of a prime number p. 
Returns 1 if it is, 0 if it is not. 
In fact it finds every primitive root of the prime number given, and every time
it compares the primitive root found with the root given. 
*/

int isPrimitiveRoot(long long int p, long long int g) {
    if (!isPrime(p)) {
        printf("%lld is not a prime number.\n", p);
        return 0;
    }

    for (long long int k = 2; k < p; k++) {
        int primitiveRoot = 1;
        for (long long int i = 1; i < p - 1; i++) {
            if (compute_key(k, i, p) == 1) {
                primitiveRoot = 0;
                break;
            }
        }
        if (primitiveRoot && g == k ) {
        	return 1;
        }
    }
    return 0;
}


int main(int argc, char* argv[]){
	long long int opt,p,g,a,b;
	char* path = NULL;
	while((opt = getopt(argc, argv, "o:p:g:a:b:h")) != -1){
        switch(opt){
            case 'o':
                path = strdup(optarg);
                break;
            case 'p':
                p = atoi(optarg);
                if (!isPrime(p)){
                    fprintf(stderr, "Error: p must be a prime number.\n");
                    exit(1);
                }
                break;
            case 'g':
                g = atoi(optarg);
                if (!isPrimitiveRoot(p,g)){
                    fprintf(stderr, "Error: g must be a primitive root.\n");
                    exit(1);
                }
                break;
            case 'a':
                a = atoi(optarg);
                if (a <= 0 || a >= p) {
                    fprintf(stderr, "Error: Private key a must be between 1 and p-1.\n");
                    exit(1);
                }
                break;
            case 'b':
                b = atoi(optarg);
                 if (b <= 0 || b >= p) {
                    fprintf(stderr, "Error: Private key b must be between 1 and p-1.\n");
                    exit(1);
                }
                break;
            case 'h':
                printf("-o\tpath\tPath to output file.\n");
                printf("-p\tnumber\tPrime Number.\n");
                printf("-g\tnumber\tPrimitive Root for previous prime number.\n");
                printf("-a\tnumber\tPrivate key A.\n");
                printf("-b\tnumber\tPrivate Key B.\n");
                printf("-h\t\tThis help message.\n");
                exit(0);
                break;
            default:
                fprintf(stderr, "Error: Try again.\n");
                exit(1);
        }
    }
     if (!path) {
        fprintf(stderr, "Error: Output path cannot be found.\n");
        exit(1);
    }

    FILE *fp = fopen(path, "w");

    if(fp == NULL){
        fprintf(stderr, "Error: Null pointer file.");
        exit(1);
    }
    
    long long int apublic = compute_key(g,a,p);
    long long int bpublic = compute_key(g,b,p);
    long long int aprivate = compute_key(bpublic,a,p);
    long long int bprivate = compute_key(apublic,b,p);

    fprintf(fp, "<%lld> <%lld> <%lld>", apublic, bpublic, aprivate);
    fclose(fp);   
    free(path);
    return 0;
}
