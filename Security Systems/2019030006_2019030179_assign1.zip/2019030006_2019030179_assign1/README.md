# Security Systems 

# Diffie-Hellman Key Exchange

## Overview

This C program implements the Diffie-Hellman key exchange algorithm, a cryptographic method that allows two parties to securely exchange a shared secret key over an insecure communication channel. The code is designed to run in a command-line environment, and it takes specific parameters as input to perform the key exchange.

## Compile
```bash
gcc -o dh_assign_1 dh_assign_1.c -lm
```
## Run & Test

### Test
```bash
./dh_assign_1 -o <output_file> -p <prime_number> -g <primitive_root> -a <private_key_a> -b <private_key_b>
-o <output_file>
```
: Path to the output file where the shared secret keys will be saved.

-p <prime_number>: Prime number (p) used in the key exchange. It must be a prime number.

-g <primitive_root>: Primitive root (g) of (p-1) used in the key exchange. It must be a primitive root of (p-1).

-a <private_key_a>: Private key A, a value between 1 and (p-1).

-b <private_key_b>: Private key B, a value between 1 and (p-1)

### Help
You can also use the -h option to display a help message.
```bash 
./dh_assign_1 -h
```

### Example:
```bash
./dh_assign_1 -o output.txt -p 23 -g 9 -a 15 -b 2
```

## Tests made in Makefile:
Firstly, you run it by typing make.
```bash
make
```
Then you run the tests by typing make <nameoftest>. You can see the tests made below:
### 1) test_notprimitive 


If a non primitive root is set as g argument, an error message is displayed.

### 2) test_primitive
If a primitive root is set a g argument, p is prime, a and b are within limits, an output file output.txt is produced.
### 3) test_agreaterthanprime
If argument a is greater than prime number, an error message is displayed.
### 4) test_bgreaterthanprime
If argument b is greater than prime number, an error message is displayed.
### 5) test_help1
Help message is displayed.


# RSA Algorithm using GMP library

## Overview

RSA (Rivest–Shamir–Adleman) is a widely used public-key cryptosystem that is used for secure data transmission and digital signatures. It involves two keys: a public key used for encryption and a private key used for decryption. RSA is based on the mathematical properties of large prime numbers and modular arithmetic.

The key components of the RSA algorithm are as follows:

### Key Generation:

Select two large prime numbers, typically denoted as p and q.

Compute their product n = p * q, which is used as the modulus for both the public and private keys.

Calculate Euler's totient function λ(n) = (p - 1) * (q - 1).

Choose a public exponent e that is coprime to λ(n). It is typically a small prime number.

Compute the private exponent d as the modular multiplicative inverse of e with respect to λ(n).

### Encryption:

To encrypt a message M, the sender uses the recipient's public key (n, e).
The ciphertext C is calculated as C = M^e (mod n).

### Decryption:

To decrypt the ciphertext C, the recipient uses their private key (n, d).
The original message M is obtained as M = C^d (mod n).
Security:

The security of RSA is based on the difficulty of factoring the product n = p * q into its prime factors p and q.
RSA is considered secure as long as the prime factors are sufficiently large.

## Run 
### Key Generation
To generate RSA key pairs, use the following command:
```bash
./rsa_assign_1 -g <key_length>
```
Replace <key_length> with the desired key length (e.g., 1024, 2048, or 4096).
The public and private keys will be saved in files named public_<key_length>.key and private_<key_length>.key.

### Encryption
To encrypt a plaintext file, use the following command:

```bash 
./rsa_assign_1 -i <input_file> -o <output_file> -k <public_key_file> -e
```

Replace <input_file> with the path to the input plaintext file.
Replace <output_file> with the path to the output ciphertext file.
Replace <public_key_file> with the path to the public key file.

### Decryption
To decrypt a ciphertext file, use the following command:

```bash
./rsa_assign_1 -i <input_file> -o <output_file> -k <private_key_file> -d
```
Replace <input_file> with the path to the input ciphertext file.
Replace <output_file> with the path to the output plaintext file.
Replace <private_key_file> with the path to the private key file.

### Performance Analysis
To compare the performance of RSA encryption and decryption with different key lengths (1024, 2048, 4096), use the following command:
```bash
./rsa_assign_1 -a <performance_log_file>
```

Replace <performance_log_file> with the name of the file where performance results will be recorded.

### Help
For more information and available options, use the following command:
```bash
./rsa_assign_1 -h
```

## Tests made in Makefile:
Firstly, you run it by typing make.
```bash
make
```
Then you run the tests by typing make <nameoftest>. You can see the tests made below:

### 1. test_generateKey
Key length is set to 1024 and the private and public keys are generated.
### 2. test_encrypt
Previous generated keys are used to encrypt the input plaintext.txt to the output ciphertext.txt file.
### 3. test_decrypt
Previous generated keys are used to decrypt the input ciphertext.txt to the output decrypted.txt
### 4. test_performance
A file performance.txt is generated in which the perfomance analysis of the various key lengths is shown.
### 5. test_help2
Help message is displayed.
