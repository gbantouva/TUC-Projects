#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/time.h>
#include <stdbool.h>
#include <gmp.h>


void help();
void generateRandomPrime(int bit_length, mpz_t prime);
void exportKeysToFile(const char* privateFileName, const char* publicFileName, mpz_t n, mpz_t d, mpz_t e);
void generateRSAKeyPair(int bit_length, char* fileName);
void find_E_and_D(mpz_t e, mpz_t lambda_n, mpz_t d);
void encryptCharacter(FILE *input_file, FILE *output_file, const mpz_t n, const mpz_t d);
void enc_file(const char *input_path, const char *output_path, const char *key_path);
void decryptCharacter(FILE *input_file, FILE *output_file, const mpz_t n, const mpz_t e);
void dec_file(const char *input_path, const char *output_path, const char *key_path);
void measure_time(char* name);
void generateAndMeasureTime(char* key_length, const char* plaintext_file, FILE* time_log_file);



int main(int argc, char *argv[]){

    int opt;
    char *input_file_holder, *out_file_holder, *key_holder;

    while((opt = getopt(argc, argv, "i:o:k:g:a:deh")) != -1){
        switch(opt){
            case 'i':
                input_file_holder = strdup(optarg);
                break;
            case 'o':
                out_file_holder = strdup(optarg);
                break;
            case 'k':
                key_holder = strdup(optarg);
                break;
            case 'g':
                generateRSAKeyPair(atoi(optarg)/2, NULL);
                break;
            case 'a':
                measure_time(strdup(optarg));
                break;
            case 'd':
                dec_file(input_file_holder, out_file_holder, key_holder);
                break;
            case 'e':
                enc_file(input_file_holder, out_file_holder, key_holder);
                break;
            case 'h':
                help();
                exit(0);
            default:
                fprintf(stderr, "Error.\n");
        }
    }
    return 0;
}

/**
 * Display a help message explaining how to use the program and its command-line options.
 */

void help() {
    printf("-i <path>\t: Path to the input file.\n");
    printf("-o <path>\t: Path to the output file.\n");
    printf("-k <path>\t: Path to the key file.\n");
    printf("-g\t\t: Perform RSA key-pair generation given a key length length.\n");
    printf("-d\t\t: Decrypt input and store results to output.\n");
    printf("-e\t\t: Encrypt input and store results to output.\n");
    printf("-a\t\t: Compare the performance of RSA encryption and decryption.\n");
    printf("-h\t\t: This help message.\n");
}

/**
 * Generate a random prime number of a specified bit length.
 * @param bit_length The desired bit length of the prime.
 * @param prime The generated prime number will be stored here.
 */

void generateRandomPrime(int bit_length, mpz_t prime) {
    gmp_randstate_t state;
    gmp_randinit_default(state);
    
    // Seed the random number generator using the current time
    unsigned long seed = time(NULL);
    gmp_randseed_ui(state, seed);

    // Ensure that the generated number has the desired bit length
    mpz_rrandomb(prime, state, bit_length);

    // Set the high and low bits to ensure it is within the desired bit length
    mpz_setbit(prime, bit_length - 1);
    mpz_setbit(prime, 0);

    // Apply the Miller-Rabin primality test to make sure it's prime
    while (!mpz_probab_prime_p(prime, 15)) {
        mpz_rrandomb(prime, state, bit_length);
        mpz_setbit(prime, bit_length - 1);
        mpz_setbit(prime, 0);
    }

    gmp_randclear(state);
}

/**
 * Export RSA keys to text files.
 *
 * @param privateFileName The name of the file to store the private key.
 * @param publicFileName The name of the file to store the public key.
 * @param n The modulus used in both keys.
 * @param d The private exponent.
 * @param e The public exponent.
 */

void exportKeysToFile(const char* privateFileName, const char* publicFileName, mpz_t n, mpz_t d, mpz_t e) {
    FILE* fp_private = fopen(privateFileName, "w");
    FILE* fp_public = fopen(publicFileName, "w");

    if (fp_private == NULL || fp_public == NULL) {
        fprintf(stderr, "Failed to open files for writing.");
        exit(1);
    }

    mpz_out_str(fp_private, 0, n);
    fprintf(fp_private, " ");
    mpz_out_str(fp_private, 0, d);

    mpz_out_str(fp_public, 0, n);
    fprintf(fp_public, " ");
    mpz_out_str(fp_public, 0, e);

    fclose(fp_private);
    fclose(fp_public);
}

/**
 * Generate RSA key pairs and export them to text files.
 *
 * @param bit_length The desired bit length for the key.
 * @param fileName The name of the output files (optional, set to NULL if not provided).
 */

void generateRSAKeyPair(int bit_length, char* fileName) {
    mpz_t n, p, q, e, d, lambda_n;

    mpz_inits(n, p, q, lambda_n, e, d, NULL);

    generateRandomPrime(bit_length, p);
    gmp_printf("Prime chosen for p: %Zd\n", p);

    generateRandomPrime(bit_length, q);
    while (mpz_cmp(p, q) == 0) {
        generateRandomPrime(bit_length, q);
    }
    gmp_printf("Prime chosen for q: %Zd\n", q);

    mpz_set_ui(e, 2);

    mpz_mul(n, p, q);
    
    mpz_sub_ui(lambda_n, p, 1);
    mpz_sub_ui(q, q, 1);
    mpz_mul(lambda_n, lambda_n, q);

    find_E_and_D(e, lambda_n, d);

    char privateFileName[100];
    char publicFileName[100];

    if (fileName == NULL) {
        snprintf(privateFileName, sizeof(privateFileName), "private_%d.key", bit_length*2);
        snprintf(publicFileName, sizeof(publicFileName), "public_%d.key", bit_length*2);

    } else {
        snprintf(privateFileName, sizeof(privateFileName), "private_%s.key", fileName);
        snprintf(publicFileName, sizeof(publicFileName), "public_%s.key", fileName);
    }

    exportKeysToFile(privateFileName, publicFileName, n, d, e);

    mpz_clears(n, p, q, lambda_n, e, d, NULL);
}

/**
 * Find valid values of e and d for RSA encryption and decryption.
 *
 * @param e The public exponent (output parameter).
 * @param lambda_n The Eyler's totient function of n.
 * @param d The private exponent (output parameter).
 */

void find_E_and_D(mpz_t e, mpz_t lambda_n, mpz_t d) {
    mpz_t one, mod, gcd;

    mpz_inits(one, mod, gcd, NULL);

    mpz_set_ui(one, 1); // Initialize a constant value of 1

    while (mpz_cmp(lambda_n, e) > 0) {
        mpz_add(e, e, one); // e += 1

        mpz_mod(mod, e, lambda_n); // temp_mod = e % lambda_n

        mpz_gcd(gcd, e, lambda_n); // calculate gcd

        // Check conditions for a valid e value
        if (mpz_probab_prime_p(e, 40) && mpz_cmp_ui(mod, 0) != 0 && mpz_cmp_ui(gcd, 1) == 0) {
            mpz_invert(d, e, lambda_n); // Calculate the modular inverse of (e, lambda_n)
            mpz_clears(one, mod, gcd, NULL);
            return;
        }
    }

    // Clean up
    mpz_clears(one, mod, gcd, NULL);
}


/**
 * Encrypts a character from the input file using the RSA algorithm.
 * 
 * @param input_file  The input file to read the character from.
 * @param output_file The output file to write the encrypted result.
 * @param n           The modulus parameter of the RSA key pair.
 * @param d           The private exponent parameter of the RSA key pair.
 */

void encryptCharacter(FILE *input_file, FILE *output_file, const mpz_t n, const mpz_t d) {
    int ch;
    if ((ch = fgetc(input_file)) != EOF) {
        mpz_t input_ch;
        mpz_init(input_ch);
        mpz_set_ui(input_ch, ch);
        mpz_powm(input_ch, input_ch, d, n);
        gmp_fprintf(output_file, "%Zd ", input_ch);
        mpz_clear(input_ch);
    }
}

/*
    Encrypts data from an input file using an RSA public key
    and saves the ciphertext to an output file.

    Parameters:
    - input_path: Path to the input file.
    - output_path: Path to the output file.
    - key_path: Path to the RSA public key file.
*/

void enc_file(const char *input_path, const char *output_path, const char *key_path) {
    mpz_t n, d;
    mpz_inits(n, d, NULL);

    FILE *input_file = fopen(input_path, "r");
    FILE *key_file = fopen(key_path, "r");
    FILE *output_file = fopen(output_path, "w");

    if (!input_file || !key_file || !output_file) {
        fprintf(stderr, "Failed to open files for reading or writing.");
        exit(1);
    }

    long long n_long, d_long;
    if (fscanf(key_file, "%lld %lld", &n_long, &d_long) != 2) {
        fprintf(stderr, "Failed to read key values from the key file.");
        exit(1);
    }

    mpz_set_si(n, n_long);
    mpz_set_si(d, d_long);

    while (!feof(input_file)) {
        encryptCharacter(input_file, output_file, n, d);
    }

    fclose(input_file);
    fclose(key_file);
    fclose(output_file);

    mpz_clears(n, d, NULL);
}

/**
 * Decrypt a single character from the input file using the given public key (n, e)
 * and write the decrypted character to the output file.
 *
 * @param input_file  File pointer to the input file containing encrypted characters.
 * @param output_file File pointer to the output file where the decrypted character will be written.
 * @param n           The public key modulus.
 * @param e           The public key exponent.
 */
 
void decryptCharacter(FILE *input_file, FILE *output_file, const mpz_t n, const mpz_t e) {
    long long encrypted_word;
    if (fscanf(input_file, "%lld", &encrypted_word) != EOF) {
        mpz_t input_text;
        mpz_init(input_text);
        mpz_set_si(input_text, encrypted_word);
        mpz_powm(input_text, input_text, e, n);
        
        char export_ch;
        mpz_export(&export_ch, NULL, 1, sizeof(char), 0, 0, input_text);
        fputc(export_ch, output_file);

        mpz_clear(input_text);
    }
}

/*
    Decrypts data from an input file using an RSA public key and writes the decrypted data to an output file.

    Parameters:
    - input_path: Path to the input file containing encrypted data.
    - output_path: Path to the output file where decrypted data will be written.
    - key_path: Path to the key file containing the RSA public key (n, e).
*/

void dec_file(const char *input_path, const char *output_path, const char *key_path) {
    mpz_t n, e;
    mpz_inits(n, e, NULL);

    FILE *input_file = fopen(input_path, "r");
    FILE *key_file = fopen(key_path, "r");
    FILE *output_file = fopen(output_path, "w");

    if (!input_file || !key_file || !output_file) {
        fprintf(stderr, "Failed to open files for reading or writing.");
        exit(1);
    }

    long long n_long, e_long;
    if (fscanf(key_file, "%lld %lld", &n_long, &e_long) != 2) {
        fprintf(stderr, "Failed to read key values from the key file.");
        exit(1);
    }

    mpz_set_si(n, n_long);
    mpz_set_si(e, e_long);

    while (!feof(input_file)) {
        decryptCharacter(input_file, output_file, n, e);
    }

    fclose(input_file);
    fclose(key_file);
    fclose(output_file);

    mpz_clears(n, e, NULL);
}

/**
 * Measure the time it takes to perform operations for different key lengths
 *
 * @param name The name of the log file to store time measurements.
 */

void measure_time(char* name) {
    FILE* time_log_file = fopen(name, "w");

    if (time_log_file == NULL) {
        perror("Failed to open the log file");
        return;
    }

    const char* plaintext_file = "plaintext.txt";
    char* key_lengths[] = { "1024", "2048", "4096" };

    for (int i = 0; i < 3; i++) {
        generateAndMeasureTime(key_lengths[i], plaintext_file, time_log_file);
    }

    // Close the file
    fclose(time_log_file);
}

/**
 * Generate key pairs, encrypt, and decrypt a plaintext file for a given key length.
 * Measure the time it takes to perform these operations and write the elapsed time to a log file.
 *
 * @param key_length The length of the key to generate and measure time for.
 * @param plaintext_file The name of the plaintext file to encrypt.
 * @param time_log_file The file to store the elapsed time measurements.
 */

void generateAndMeasureTime(char* key_length, const char* plaintext_file, FILE* time_log_file) {
    clock_t start_time, end_time;
    double cpu_time_used;

    // Generate key pairs
    generateRSAKeyPair(atoi(key_length), key_length);

    // Encryption and decryption
    char private_key_file[100];
    char public_key_file[100];

    snprintf(private_key_file, sizeof(private_key_file), "private_%s.key", key_length);
    snprintf(public_key_file, sizeof(public_key_file), "public_%s.key", key_length);

    // Encryption
    start_time = clock();
    enc_file(plaintext_file, "ciphertext.txt", public_key_file);
    dec_file("ciphertext.txt", "decrypted.txt", private_key_file);

    end_time = clock();
    cpu_time_used = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

    // Write the elapsed time to the file
    fprintf(time_log_file, "Time taken for %s-bit keys: %f seconds\n", key_length, cpu_time_used);
}


