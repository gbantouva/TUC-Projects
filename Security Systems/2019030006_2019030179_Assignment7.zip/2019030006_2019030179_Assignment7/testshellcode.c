#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void shell_pwn()
{
    const char code[] =
        "\x48\x31\xc0\x50\x48\x89\xe2\x48\xbb\x2f\x2f\x62\x69\x6e\x2f\x73\x68\x53\x48\x89\xe7\x50\x57\x48\x89\xe6\x48\x83\xc0\x3b\x0f\x05";

    // Function pointer to cast and execute the shellcode
    void (*ret)() = (void(*)())code;

    // Call the shellcode
    ret();
}

int copytobuffer(char* input)
{
    char buffer[15];
    strcpy(buffer, input);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc != 2) {
        printf("Usage: %s <input>\n", argv[0]);
        return 1;
    }

 

    int local_variable = 1;
    copytobuffer(argv[1]);


    return 0;
}


