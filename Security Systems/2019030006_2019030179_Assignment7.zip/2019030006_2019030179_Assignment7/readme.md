# Security Systems - Assignment 7
## Buffer Overflow Exploitation
##### Georgia Bantouva 2019030006
##### Stefanaki Maria 2019030179

## Overview
Our task involved creating a script to exploit a buffer overflow vulnerability by taking advantage of the executable status of the Name array in the given program, established through mprotect.

## Exploitation Steps
1. Overflow Stack Buffer:
        Flood the stack buffer with InputGenerator output.
2. Copy to Executable Array:
        Transfer the buffer contents to the executable Name array.
3. Jump to Modified Address:
        Navigate to the Name array's starting address + 4 bytes.
4. Execute Shell Code:
        Trigger the execution of shell code, enabling a user-level shell.

## How to run
Feed the exploit.txt directly to the program:
(cat ./exploit.txt; cat) | ./Greeter

Firstly make sure the gcc-multilib package is installed:
$ sudo apt-get install gcc-multilib

$ make all

Then at the end $ make clean
