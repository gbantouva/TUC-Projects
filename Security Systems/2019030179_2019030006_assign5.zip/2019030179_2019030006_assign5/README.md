# Systems Security - Assignment 5
Stefanaki Maria - 2019030179

Bantouva Georgia - 2019030006

## Implementation
In this assignment we created a simple adblocking mechanism using iptables.The script reads domain names from domainNames.txt and IP addresses from IPAddresses.txt. It then configures iptables rules to reject connections from these domains or IP addresses. The rules can be saved to and loaded from the adblockRules file.

## Execution

```bash
# Give execute privilege
chmod +x adblock.sh 

# Configure adblock rules based on the domain names of domainNames.txt.
sudo ./adblock.sh -domains

# Configure adblock rules based on the IP addresses of IPAddresses.txt.
sudo ./adblock.sh -ips

# Save current rules to the adblockRules file.
sudo ./adblock.sh -save

# Load rules from the adblockRules file.
sudo ./adblock.sh -load

# List the current iptables rules.
sudo ./adblock.sh -list

# Reset rules to default settings (accept all).
sudo ./adblock.sh -reset

# Display help and exit.
sudo ./adblock.sh -help
```
## Question
Not all advertisements can be deleted, because most sites have strong detection of adblock mechanisms and rejects them. 
