#include <stdlib.h>
#include <stdio.h>
#include <pcap.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <string.h>
#include <getopt.h>
#include <signal.h>
#include <arpa/inet.h>

#define SNAP_LEN 1518
#define SIZE_ETHERNET 14

int tcp_packet_counter = 0;
int udp_packet_counter = 0;
int packet_counter = 0;
int udp_bytes = 0;
int tcp_bytes = 0;
int net_flows = 0;
int retrans_counter = 0;

FILE *log_file = NULL;
char *dev = NULL;  

void open_log_file() {
    log_file = fopen("log.txt", "w");
    if (log_file == NULL) {
        perror("Error opening log file");
        exit(EXIT_FAILURE);
    }
}

void close_log_file() {
    if (log_file != NULL) {
        fclose(log_file);
    }
}

void print_packet_info(const char *protocol, const struct ip *ip_header, int src_port, int dst_port, int payload_size, int write_to_log) {
    printf("Protocol: %s\n", protocol);
    printf("From: %s\n", inet_ntoa(ip_header->ip_src));
    printf("To: %s\n", inet_ntoa(ip_header->ip_dst));
    printf("Src port: %d\n", src_port);
    printf("Dst port: %d\n", dst_port);

    if (payload_size > 0) {
        printf("Payload (%d bytes):\n", payload_size);
    }
    printf("\n");

    if (write_to_log && log_file != NULL) {
        fprintf(log_file, "Protocol: %s\n", protocol);
        fprintf(log_file, "From: %s\n", inet_ntoa(ip_header->ip_src));
        fprintf(log_file, "To: %s\n", inet_ntoa(ip_header->ip_dst));
        fprintf(log_file, "Source port: %d\n", src_port);
        fprintf(log_file, "Destination port: %d\n", dst_port);

        if (payload_size > 0) {
            fprintf(log_file, "Payload (%d bytes):\n", payload_size);
        }
        fprintf(log_file, "\n");
        fflush(log_file); 
    }
}

void sigint_handler(int signum) {
    printf("\nNumber of packets: %d\n", packet_counter);
    printf("\nNumber of TCP packets: %d\n", tcp_packet_counter);
    printf("\nNumber of UDP packets: %d\n", udp_packet_counter);
    printf("\nNumber of network flows: %d\n", net_flows);
    printf("\nNumber of TCP bytes: %d\n", tcp_bytes);
    printf("\nNumber of UDP bytes: %d\n", udp_bytes);
    printf("\nNumber of retransmitted packets: %d\n", retrans_counter);

    if (dev != NULL) {
        close_log_file();
    }

    signal(SIGINT, SIG_DFL);
    raise(SIGINT);
}

void packet_handler(u_char *param, const struct pcap_pkthdr *header, const u_char *pkt_data) {
    const struct ip *ip_header = (struct ip *)(pkt_data + SIZE_ETHERNET);
    int size_ip = ip_header->ip_hl * 4;

    if (size_ip < 20) {
        fprintf(stderr, "Invalid IP header length: %u bytes\n", size_ip);
        return;
    }

    packet_counter++;

    switch (ip_header->ip_p) {
        case IPPROTO_TCP: {
            const struct tcphdr *tcp_header = (struct tcphdr *)(pkt_data + SIZE_ETHERNET + size_ip);
            int size_tcp = tcp_header->th_off * 4;
            int payload_size = ntohs(ip_header->ip_len) - size_ip - size_tcp;

            tcp_packet_counter++;
            tcp_bytes += header->len;

            print_packet_info("TCP", ip_header, ntohs(tcp_header->th_sport), ntohs(tcp_header->th_dport), payload_size, dev != NULL);

            if (tcp_header->th_flags & TH_RST) {
                retrans_counter++;
            }
            break;
        }
        case IPPROTO_UDP: {
            const struct udphdr *udp_header = (struct udphdr *)(pkt_data + SIZE_ETHERNET + size_ip);
            int payload_size = ntohs(udp_header->uh_ulen) - sizeof(struct udphdr);

            udp_packet_counter++;
            udp_bytes += header->len;

            print_packet_info("UDP", ip_header, ntohs(udp_header->uh_sport), ntohs(udp_header->uh_dport), payload_size, dev != NULL);

            if (ntohs(udp_header->uh_sport) == 2055 || ntohs(udp_header->uh_dport) == 2055) {
                net_flows++;
            }
            break;
        }
        default:
            printf("Protocol: unknown\n");
            break;
    }
}

int main(int argc, char *argv[]) {
    char errbuf[PCAP_ERRBUF_SIZE];
    char *file = NULL;
    char *filter_exp = NULL;
    pcap_t *handle;
    struct bpf_program fp;
    bpf_u_int32 net;
    int opt;

    while ((opt = getopt(argc, argv, "i:r:f:h")) != -1) {
        switch (opt) {
            case 'i':
                dev = optarg;
                break;
            case 'r':
                file = optarg;
                break;
            case 'f':
                filter_exp = optarg;
                break;
            case 'h':
		    printf("Help message\n");
		    printf("-i: Select the network interface name (e.g., eth0)\n");
		    printf("-r: Packet capture file name (e.g., test.pcap)\n");
		    printf("-f: Filter expression in string format (e.g., port 8080)\n");
		    exit(1);            	
            default:
                fprintf(stderr, "Usage: %s [-i interface | -r file | -f filter]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    if (dev != NULL) {
        open_log_file();
    }

    signal(SIGINT, sigint_handler);

    if (file != NULL) {
        handle = pcap_open_offline(file, errbuf);
    } else if (dev != NULL) {
        handle = pcap_open_live(dev, SNAP_LEN, 1, 1000, errbuf);
        if (handle == NULL) {
            fprintf(stderr, "Couldn't open device %s: %s\n", dev, errbuf);
            exit(EXIT_FAILURE);
        }
    } else {
        fprintf(stderr, "Please specify an interface (-i) or a file (-r)\n");
        exit(EXIT_FAILURE);
    }

    pcap_loop(handle, 0, packet_handler, NULL);

	if (file != NULL) {
        sigint_handler(SIGINT);
    }

    if (dev != NULL) {
        close_log_file();
    }

    return EXIT_SUCCESS;
}
