# ASSIGNMENT 4
Stefanaki Maria 2019030179
Bantouva Georgia 2019030006

## Implementation
This network monitoring tool is implemented in C, utilizing the libpcap library for packet capturing. The program can capture live network packets from a specified network interface (-i option), read packets from a pcap file (-r option), extract information about UDP and TCP packets and apply filters to capture specific types of packets (-f option).

## Compilation
make all

## Execution
Live:sudo ./pcap_ex  -i <interface> 

Offline: sudo ./pcap_ex -r <filename> 

Filter: sudo ./pcap_ex -i <interface> -f <filter_expression>

## Run examples 
sudo ./pcap_ex -i eth0/enp0s3

sudo ./pcap_ex -r test_pcap_5mins.pcap
           
sudo ./pcap_ex -i eth0/enp0s3 -f “src port 53”

## Questions

Can you tell if an incoming TCP packet is a retransmission? If yes, how? If not, why?

Yes, by examing the TCP's header sequence number we can tell if a TCP packet is a retransmission.

Can you tell if an incoming UDP packet is a retransmission? If yes, how? If not, why?

No, we cannot tell if a UDP packet is re-transmitted because it is a connection-less protocol at the transport layer.
