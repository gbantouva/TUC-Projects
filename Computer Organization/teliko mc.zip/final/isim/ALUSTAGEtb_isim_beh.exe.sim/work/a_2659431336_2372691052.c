/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/georg/Desktop/COMP/teleutaio/final/ALUSTAGEtb.vhd";
extern char *IEEE_P_3620187407;

char *ieee_p_3620187407_sub_767668596_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_2659431336_2372691052_p_0(char *t0)
{
    char t14[16];
    char t15[16];
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    int t10;
    int t11;
    char *t12;
    char *t13;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned char t19;
    char *t20;
    char *t21;
    char *t22;

LAB0:    t1 = (t0 + 3472U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(104, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(109, ng0);
    t2 = (t0 + 6712);
    t5 = (t0 + 3856);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 32U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(110, ng0);
    t2 = (t0 + 6744);
    t5 = (t0 + 3920);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 32U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 6776);
    t5 = (t0 + 3984);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 32U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(112, ng0);
    t2 = (t0 + 4048);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(113, ng0);
    t2 = (t0 + 6808);
    t5 = (t0 + 4112);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(114, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(116, ng0);
    t2 = (t0 + 4048);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 6812);
    t5 = (t0 + 4112);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(118, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB12:    xsi_set_current_line(120, ng0);
    t2 = (t0 + 6816);
    t5 = (t0 + 4112);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(121, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB18:    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

LAB16:    xsi_set_current_line(123, ng0);
    t2 = (t0 + 4048);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(124, ng0);
    t2 = (t0 + 6820);
    t5 = (t0 + 4112);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(125, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB22:    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB17:    goto LAB16;

LAB19:    goto LAB17;

LAB20:    xsi_set_current_line(127, ng0);
    t2 = (t0 + 4048);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(128, ng0);
    t2 = (t0 + 6824);
    t5 = (t0 + 4112);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(129, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB26:    *((char **)t1) = &&LAB27;
    goto LAB1;

LAB21:    goto LAB20;

LAB23:    goto LAB21;

LAB24:    xsi_set_current_line(131, ng0);
    t2 = (t0 + 6828);
    t5 = (t0 + 4112);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(132, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB30:    *((char **)t1) = &&LAB31;
    goto LAB1;

LAB25:    goto LAB24;

LAB27:    goto LAB25;

LAB28:    xsi_set_current_line(134, ng0);
    t2 = (t0 + 6832);
    *((int *)t2) = 0;
    t4 = (t0 + 6836);
    *((int *)t4) = 1;
    t10 = 0;
    t11 = 1;

LAB32:    if (t10 <= t11)
        goto LAB33;

LAB35:    xsi_set_current_line(142, ng0);
    t2 = (t0 + 6875);
    t5 = (t0 + 4112);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(143, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB49:    *((char **)t1) = &&LAB50;
    goto LAB1;

LAB29:    goto LAB28;

LAB31:    goto LAB29;

LAB33:    xsi_set_current_line(135, ng0);
    t5 = (t0 + 6840);
    t7 = (t0 + 3984);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t12 = (t9 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t5, 32U);
    xsi_driver_first_trans_fast(t7);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t2 = (t0 + 6488U);
    t5 = (t0 + 6872);
    t7 = (t15 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (0 - 0);
    t17 = (t16 * 1);
    t17 = (t17 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t17;
    t8 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t14, t4, t2, t5, t15);
    t9 = (t14 + 12U);
    t17 = *((unsigned int *)t9);
    t18 = (1U * t17);
    t19 = (32U != t18);
    if (t19 == 1)
        goto LAB36;

LAB37:    t12 = (t0 + 3856);
    t13 = (t12 + 56U);
    t20 = *((char **)t13);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t8, 32U);
    xsi_driver_first_trans_fast(t12);
    xsi_set_current_line(137, ng0);
    t2 = (t0 + 1192U);
    t4 = *((char **)t2);
    t2 = (t0 + 6504U);
    t5 = (t0 + 6873);
    t7 = (t15 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (0 - 0);
    t17 = (t16 * 1);
    t17 = (t17 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t17;
    t8 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t14, t4, t2, t5, t15);
    t9 = (t14 + 12U);
    t17 = *((unsigned int *)t9);
    t18 = (1U * t17);
    t19 = (32U != t18);
    if (t19 == 1)
        goto LAB38;

LAB39:    t12 = (t0 + 3920);
    t13 = (t12 + 56U);
    t20 = *((char **)t13);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t8, 32U);
    xsi_driver_first_trans_fast(t12);
    xsi_set_current_line(138, ng0);
    t2 = (t0 + 1672U);
    t4 = *((char **)t2);
    t2 = (t0 + 6536U);
    t5 = (t0 + 6874);
    t7 = (t15 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (0 - 0);
    t17 = (t16 * 1);
    t17 = (t17 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t17;
    t8 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t14, t4, t2, t5, t15);
    t9 = (t14 + 12U);
    t17 = *((unsigned int *)t9);
    t18 = (1U * t17);
    t19 = (4U != t18);
    if (t19 == 1)
        goto LAB40;

LAB41:    t12 = (t0 + 4112);
    t13 = (t12 + 56U);
    t20 = *((char **)t13);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    memcpy(t22, t8, 4U);
    xsi_driver_first_trans_fast(t12);
    xsi_set_current_line(139, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB44:    *((char **)t1) = &&LAB45;
    goto LAB1;

LAB34:    t2 = (t0 + 6832);
    t10 = *((int *)t2);
    t4 = (t0 + 6836);
    t11 = *((int *)t4);
    if (t10 == t11)
        goto LAB35;

LAB46:    t16 = (t10 + 1);
    t10 = t16;
    t5 = (t0 + 6832);
    *((int *)t5) = t10;
    goto LAB32;

LAB36:    xsi_size_not_matching(32U, t18, 0);
    goto LAB37;

LAB38:    xsi_size_not_matching(32U, t18, 0);
    goto LAB39;

LAB40:    xsi_size_not_matching(4U, t18, 0);
    goto LAB41;

LAB42:    goto LAB34;

LAB43:    goto LAB42;

LAB45:    goto LAB43;

LAB47:    xsi_set_current_line(145, ng0);
    t2 = (t0 + 6879);
    t5 = (t0 + 4112);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 4U);
    xsi_driver_first_trans_fast(t5);
    xsi_set_current_line(146, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3280);
    xsi_process_wait(t2, t3);

LAB53:    *((char **)t1) = &&LAB54;
    goto LAB1;

LAB48:    goto LAB47;

LAB50:    goto LAB48;

LAB51:    xsi_set_current_line(148, ng0);

LAB57:    *((char **)t1) = &&LAB58;
    goto LAB1;

LAB52:    goto LAB51;

LAB54:    goto LAB52;

LAB55:    goto LAB2;

LAB56:    goto LAB55;

LAB58:    goto LAB56;

}


extern void work_a_2659431336_2372691052_init()
{
	static char *pe[] = {(void *)work_a_2659431336_2372691052_p_0};
	xsi_register_didat("work_a_2659431336_2372691052", "isim/ALUSTAGEtb_isim_beh.exe.sim/work/a_2659431336_2372691052.didat");
	xsi_register_executes(pe);
}
