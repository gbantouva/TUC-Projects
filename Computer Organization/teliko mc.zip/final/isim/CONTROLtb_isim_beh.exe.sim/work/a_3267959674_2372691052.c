/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/georg/Desktop/COMP/teleutaio/final/CONTROLtb.vhd";



static void work_a_3267959674_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    unsigned char t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 4112U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(115, ng0);
    t2 = (t0 + 4496);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(116, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(121, ng0);
    t2 = (t0 + 4496);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(125, ng0);
    t2 = (t0 + 7484);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB8;

LAB9:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(126, ng0);
    t2 = (t0 + 7490);
    t8 = (20U != 20U);
    if (t8 == 1)
        goto LAB10;

LAB11:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 20U);
    xsi_driver_first_trans_delta(t4, 6U, 20U, 0LL);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 7510);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB12;

LAB13:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(130, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB16:    *((char **)t1) = &&LAB17;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB9;

LAB10:    xsi_size_not_matching(20U, 20U, 0);
    goto LAB11;

LAB12:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB13;

LAB14:    xsi_set_current_line(132, ng0);
    t2 = (t0 + 7516);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB18;

LAB19:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(133, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB22:    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB15:    goto LAB14;

LAB17:    goto LAB15;

LAB18:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB19;

LAB20:    xsi_set_current_line(135, ng0);
    t2 = (t0 + 7522);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB24;

LAB25:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(136, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB28:    *((char **)t1) = &&LAB29;
    goto LAB1;

LAB21:    goto LAB20;

LAB23:    goto LAB21;

LAB24:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB25;

LAB26:    xsi_set_current_line(138, ng0);
    t2 = (t0 + 7528);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB30;

LAB31:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(139, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB34:    *((char **)t1) = &&LAB35;
    goto LAB1;

LAB27:    goto LAB26;

LAB29:    goto LAB27;

LAB30:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB31;

LAB32:    xsi_set_current_line(141, ng0);
    t2 = (t0 + 7534);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB36;

LAB37:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(142, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB40:    *((char **)t1) = &&LAB41;
    goto LAB1;

LAB33:    goto LAB32;

LAB35:    goto LAB33;

LAB36:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB37;

LAB38:    xsi_set_current_line(144, ng0);
    t2 = (t0 + 7540);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB42;

LAB43:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(145, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB46:    *((char **)t1) = &&LAB47;
    goto LAB1;

LAB39:    goto LAB38;

LAB41:    goto LAB39;

LAB42:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB43;

LAB44:    xsi_set_current_line(147, ng0);
    t2 = (t0 + 7546);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB48;

LAB49:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(148, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB52:    *((char **)t1) = &&LAB53;
    goto LAB1;

LAB45:    goto LAB44;

LAB47:    goto LAB45;

LAB48:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB49;

LAB50:    xsi_set_current_line(150, ng0);
    t2 = (t0 + 7552);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB54;

LAB55:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(151, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB58:    *((char **)t1) = &&LAB59;
    goto LAB1;

LAB51:    goto LAB50;

LAB53:    goto LAB51;

LAB54:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB55;

LAB56:    xsi_set_current_line(153, ng0);
    t2 = (t0 + 7558);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB60;

LAB61:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(154, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB64:    *((char **)t1) = &&LAB65;
    goto LAB1;

LAB57:    goto LAB56;

LAB59:    goto LAB57;

LAB60:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB61;

LAB62:    xsi_set_current_line(156, ng0);
    t2 = (t0 + 7564);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB66;

LAB67:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(157, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB70:    *((char **)t1) = &&LAB71;
    goto LAB1;

LAB63:    goto LAB62;

LAB65:    goto LAB63;

LAB66:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB67;

LAB68:    xsi_set_current_line(159, ng0);
    t2 = (t0 + 7570);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB72;

LAB73:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(160, ng0);
    t2 = (t0 + 7576);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB74;

LAB75:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 26U, 6U, 0LL);
    xsi_set_current_line(161, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB78:    *((char **)t1) = &&LAB79;
    goto LAB1;

LAB69:    goto LAB68;

LAB71:    goto LAB69;

LAB72:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB73;

LAB74:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB75;

LAB76:    xsi_set_current_line(163, ng0);
    t2 = (t0 + 7582);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB80;

LAB81:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(164, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB84:    *((char **)t1) = &&LAB85;
    goto LAB1;

LAB77:    goto LAB76;

LAB79:    goto LAB77;

LAB80:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB81;

LAB82:    xsi_set_current_line(166, ng0);
    t2 = (t0 + 7588);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB86;

LAB87:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(167, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB90:    *((char **)t1) = &&LAB91;
    goto LAB1;

LAB83:    goto LAB82;

LAB85:    goto LAB83;

LAB86:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB87;

LAB88:    xsi_set_current_line(169, ng0);
    t2 = (t0 + 7594);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB92;

LAB93:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(170, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB96:    *((char **)t1) = &&LAB97;
    goto LAB1;

LAB89:    goto LAB88;

LAB91:    goto LAB89;

LAB92:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB93;

LAB94:    xsi_set_current_line(172, ng0);
    t2 = (t0 + 7600);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB98;

LAB99:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(173, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB102:    *((char **)t1) = &&LAB103;
    goto LAB1;

LAB95:    goto LAB94;

LAB97:    goto LAB95;

LAB98:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB99;

LAB100:    xsi_set_current_line(175, ng0);
    t2 = (t0 + 7606);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB104;

LAB105:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(176, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB108:    *((char **)t1) = &&LAB109;
    goto LAB1;

LAB101:    goto LAB100;

LAB103:    goto LAB101;

LAB104:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB105;

LAB106:    xsi_set_current_line(178, ng0);
    t2 = (t0 + 7612);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB110;

LAB111:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(179, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB114:    *((char **)t1) = &&LAB115;
    goto LAB1;

LAB107:    goto LAB106;

LAB109:    goto LAB107;

LAB110:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB111;

LAB112:    xsi_set_current_line(181, ng0);
    t2 = (t0 + 4624);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(182, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB118:    *((char **)t1) = &&LAB119;
    goto LAB1;

LAB113:    goto LAB112;

LAB115:    goto LAB113;

LAB116:    xsi_set_current_line(184, ng0);
    t2 = (t0 + 7618);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB120;

LAB121:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(185, ng0);
    t2 = (t0 + 4624);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(186, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB124:    *((char **)t1) = &&LAB125;
    goto LAB1;

LAB117:    goto LAB116;

LAB119:    goto LAB117;

LAB120:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB121;

LAB122:    xsi_set_current_line(188, ng0);
    t2 = (t0 + 4624);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(189, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB128:    *((char **)t1) = &&LAB129;
    goto LAB1;

LAB123:    goto LAB122;

LAB125:    goto LAB123;

LAB126:    xsi_set_current_line(191, ng0);
    t2 = (t0 + 7624);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB130;

LAB131:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(192, ng0);
    t2 = (t0 + 4624);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(193, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB134:    *((char **)t1) = &&LAB135;
    goto LAB1;

LAB127:    goto LAB126;

LAB129:    goto LAB127;

LAB130:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB131;

LAB132:    xsi_set_current_line(195, ng0);
    t2 = (t0 + 7630);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB136;

LAB137:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(196, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB140:    *((char **)t1) = &&LAB141;
    goto LAB1;

LAB133:    goto LAB132;

LAB135:    goto LAB133;

LAB136:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB137;

LAB138:    xsi_set_current_line(198, ng0);
    t2 = (t0 + 7636);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB142;

LAB143:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(199, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB146:    *((char **)t1) = &&LAB147;
    goto LAB1;

LAB139:    goto LAB138;

LAB141:    goto LAB139;

LAB142:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB143;

LAB144:    xsi_set_current_line(201, ng0);
    t2 = (t0 + 7642);
    t8 = (6U != 6U);
    if (t8 == 1)
        goto LAB148;

LAB149:    t4 = (t0 + 4560);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t9 = (t6 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t2, 6U);
    xsi_driver_first_trans_delta(t4, 0U, 6U, 0LL);
    xsi_set_current_line(202, ng0);
    t7 = (100 * 1000LL);
    t2 = (t0 + 3920);
    xsi_process_wait(t2, t7);

LAB152:    *((char **)t1) = &&LAB153;
    goto LAB1;

LAB145:    goto LAB144;

LAB147:    goto LAB145;

LAB148:    xsi_size_not_matching(6U, 6U, 0);
    goto LAB149;

LAB150:    xsi_set_current_line(203, ng0);

LAB156:    *((char **)t1) = &&LAB157;
    goto LAB1;

LAB151:    goto LAB150;

LAB153:    goto LAB151;

LAB154:    goto LAB2;

LAB155:    goto LAB154;

LAB157:    goto LAB155;

}


extern void work_a_3267959674_2372691052_init()
{
	static char *pe[] = {(void *)work_a_3267959674_2372691052_p_0};
	xsi_register_didat("work_a_3267959674_2372691052", "isim/CONTROLtb_isim_beh.exe.sim/work/a_3267959674_2372691052.didat");
	xsi_register_executes(pe);
}
