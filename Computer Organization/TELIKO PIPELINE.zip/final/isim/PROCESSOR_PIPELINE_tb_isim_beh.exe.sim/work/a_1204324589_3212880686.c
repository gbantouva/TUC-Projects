/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/georg/Downloads/Me ths xrys kai me kainourio coe/final/MUX3_1.vhd";



static void work_a_1204324589_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    int t5;
    char *t6;
    char *t7;
    int t8;
    char *t9;
    char *t10;
    int t11;
    int64 t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;

LAB0:    t1 = (t0 + 2992U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(44, ng0);
    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 5598);
    t5 = xsi_mem_cmp(t2, t3, 2U);
    if (t5 == 1)
        goto LAB5;

LAB9:    t6 = (t0 + 5600);
    t8 = xsi_mem_cmp(t6, t3, 2U);
    if (t8 == 1)
        goto LAB6;

LAB10:    t9 = (t0 + 5602);
    t11 = xsi_mem_cmp(t9, t3, 2U);
    if (t11 == 1)
        goto LAB7;

LAB11:
LAB8:    xsi_set_current_line(45, ng0);
    t12 = (10 * 1000LL);
    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t2 = (t0 + 3392);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t9 = *((char **)t7);
    memcpy(t9, t3, 32U);
    xsi_driver_first_trans_delta(t2, 0U, 32U, t12);
    t10 = (t0 + 3392);
    xsi_driver_intertial_reject(t10, t12, t12);

LAB4:    xsi_set_current_line(44, ng0);

LAB15:    t2 = (t0 + 3312);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB16;

LAB1:    return;
LAB5:    xsi_set_current_line(45, ng0);
    t12 = (10 * 1000LL);
    t13 = (t0 + 1032U);
    t14 = *((char **)t13);
    t13 = (t0 + 3392);
    t15 = (t13 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t14, 32U);
    xsi_driver_first_trans_delta(t13, 0U, 32U, t12);
    t19 = (t0 + 3392);
    xsi_driver_intertial_reject(t19, t12, t12);
    goto LAB4;

LAB6:    xsi_set_current_line(45, ng0);
    t12 = (10 * 1000LL);
    t2 = (t0 + 1192U);
    t3 = *((char **)t2);
    t2 = (t0 + 3392);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t9 = *((char **)t7);
    memcpy(t9, t3, 32U);
    xsi_driver_first_trans_delta(t2, 0U, 32U, t12);
    t10 = (t0 + 3392);
    xsi_driver_intertial_reject(t10, t12, t12);
    goto LAB4;

LAB7:    xsi_set_current_line(45, ng0);
    t12 = (10 * 1000LL);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t2 = (t0 + 3392);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t9 = *((char **)t7);
    memcpy(t9, t3, 32U);
    xsi_driver_first_trans_delta(t2, 0U, 32U, t12);
    t10 = (t0 + 3392);
    xsi_driver_intertial_reject(t10, t12, t12);
    goto LAB4;

LAB12:;
LAB13:    t3 = (t0 + 3312);
    *((int *)t3) = 0;
    goto LAB2;

LAB14:    goto LAB13;

LAB16:    goto LAB14;

}


extern void work_a_1204324589_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1204324589_3212880686_p_0};
	xsi_register_didat("work_a_1204324589_3212880686", "isim/PROCESSOR_PIPELINE_tb_isim_beh.exe.sim/work/a_1204324589_3212880686.didat");
	xsi_register_executes(pe);
}
