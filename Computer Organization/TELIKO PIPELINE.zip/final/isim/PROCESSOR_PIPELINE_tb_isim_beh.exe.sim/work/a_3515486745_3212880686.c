/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/georg/Downloads/Me ths xrys kai me kainourio coe/final/Forwarding_Unit.vhd";



static void work_a_3515486745_3212880686_p_0(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned char t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    xsi_set_current_line(51, ng0);
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 == 1)
        goto LAB28;

LAB29:    t2 = (unsigned char)0;

LAB30:    if (t2 == 1)
        goto LAB25;

LAB26:    t1 = (unsigned char)0;

LAB27:    if (t1 != 0)
        goto LAB23;

LAB24:    xsi_set_current_line(56, ng0);
    t3 = (t0 + 7106);
    t7 = (t0 + 4296);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t3, 2U);
    xsi_driver_first_trans_fast_port(t7);

LAB3:    t3 = (t0 + 4200);
    *((int *)t3) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(52, ng0);
    t19 = (t0 + 7097);
    t21 = (t0 + 4296);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t19, 2U);
    xsi_driver_first_trans_fast_port(t21);
    goto LAB3;

LAB5:    t13 = (t0 + 1512U);
    t14 = *((char **)t13);
    t13 = (t0 + 1672U);
    t15 = *((char **)t13);
    t16 = 1;
    if (5U == 5U)
        goto LAB17;

LAB18:    t16 = 0;

LAB19:    t1 = t16;
    goto LAB7;

LAB8:    t3 = (t0 + 1512U);
    t7 = *((char **)t3);
    t3 = (t0 + 7092);
    t9 = 1;
    if (5U == 5U)
        goto LAB11;

LAB12:    t9 = 0;

LAB13:    t2 = (!(t9));
    goto LAB10;

LAB11:    t10 = 0;

LAB14:    if (t10 < 5U)
        goto LAB15;
    else
        goto LAB13;

LAB15:    t11 = (t7 + t10);
    t12 = (t3 + t10);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB12;

LAB16:    t10 = (t10 + 1);
    goto LAB14;

LAB17:    t17 = 0;

LAB20:    if (t17 < 5U)
        goto LAB21;
    else
        goto LAB19;

LAB21:    t13 = (t14 + t17);
    t18 = (t15 + t17);
    if (*((unsigned char *)t13) != *((unsigned char *)t18))
        goto LAB18;

LAB22:    t17 = (t17 + 1);
    goto LAB20;

LAB23:    xsi_set_current_line(54, ng0);
    t19 = (t0 + 7104);
    t21 = (t0 + 4296);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t19, 2U);
    xsi_driver_first_trans_fast_port(t21);
    goto LAB3;

LAB25:    t13 = (t0 + 2152U);
    t14 = *((char **)t13);
    t13 = (t0 + 1672U);
    t15 = *((char **)t13);
    t16 = 1;
    if (5U == 5U)
        goto LAB37;

LAB38:    t16 = 0;

LAB39:    t1 = t16;
    goto LAB27;

LAB28:    t3 = (t0 + 2152U);
    t7 = *((char **)t3);
    t3 = (t0 + 7099);
    t9 = 1;
    if (5U == 5U)
        goto LAB31;

LAB32:    t9 = 0;

LAB33:    t2 = (!(t9));
    goto LAB30;

LAB31:    t10 = 0;

LAB34:    if (t10 < 5U)
        goto LAB35;
    else
        goto LAB33;

LAB35:    t11 = (t7 + t10);
    t12 = (t3 + t10);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB32;

LAB36:    t10 = (t10 + 1);
    goto LAB34;

LAB37:    t17 = 0;

LAB40:    if (t17 < 5U)
        goto LAB41;
    else
        goto LAB39;

LAB41:    t13 = (t14 + t17);
    t18 = (t15 + t17);
    if (*((unsigned char *)t13) != *((unsigned char *)t18))
        goto LAB38;

LAB42:    t17 = (t17 + 1);
    goto LAB40;

}

static void work_a_3515486745_3212880686_p_1(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned char t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    xsi_set_current_line(62, ng0);
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 == 1)
        goto LAB28;

LAB29:    t2 = (unsigned char)0;

LAB30:    if (t2 == 1)
        goto LAB25;

LAB26:    t1 = (unsigned char)0;

LAB27:    if (t1 != 0)
        goto LAB23;

LAB24:    t3 = (t0 + 2152U);
    t4 = *((char **)t3);
    t3 = (t0 + 1832U);
    t7 = *((char **)t3);
    t2 = 1;
    if (5U == 5U)
        goto LAB48;

LAB49:    t2 = 0;

LAB50:    if (t2 == 1)
        goto LAB45;

LAB46:    t1 = (unsigned char)0;

LAB47:    if (t1 != 0)
        goto LAB43;

LAB44:    xsi_set_current_line(69, ng0);
    t3 = (t0 + 7124);
    t7 = (t0 + 4360);
    t8 = (t7 + 56U);
    t11 = *((char **)t8);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t3, 2U);
    xsi_driver_first_trans_fast_port(t7);

LAB3:    t3 = (t0 + 4216);
    *((int *)t3) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(63, ng0);
    t19 = (t0 + 7113);
    t21 = (t0 + 4360);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t19, 2U);
    xsi_driver_first_trans_fast_port(t21);
    goto LAB3;

LAB5:    t13 = (t0 + 1512U);
    t14 = *((char **)t13);
    t13 = (t0 + 1992U);
    t15 = *((char **)t13);
    t16 = 1;
    if (5U == 5U)
        goto LAB17;

LAB18:    t16 = 0;

LAB19:    t1 = t16;
    goto LAB7;

LAB8:    t3 = (t0 + 1512U);
    t7 = *((char **)t3);
    t3 = (t0 + 7108);
    t9 = 1;
    if (5U == 5U)
        goto LAB11;

LAB12:    t9 = 0;

LAB13:    t2 = (!(t9));
    goto LAB10;

LAB11:    t10 = 0;

LAB14:    if (t10 < 5U)
        goto LAB15;
    else
        goto LAB13;

LAB15:    t11 = (t7 + t10);
    t12 = (t3 + t10);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB12;

LAB16:    t10 = (t10 + 1);
    goto LAB14;

LAB17:    t17 = 0;

LAB20:    if (t17 < 5U)
        goto LAB21;
    else
        goto LAB19;

LAB21:    t13 = (t14 + t17);
    t18 = (t15 + t17);
    if (*((unsigned char *)t13) != *((unsigned char *)t18))
        goto LAB18;

LAB22:    t17 = (t17 + 1);
    goto LAB20;

LAB23:    xsi_set_current_line(65, ng0);
    t19 = (t0 + 7120);
    t21 = (t0 + 4360);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t19, 2U);
    xsi_driver_first_trans_fast_port(t21);
    goto LAB3;

LAB25:    t13 = (t0 + 2152U);
    t14 = *((char **)t13);
    t13 = (t0 + 1992U);
    t15 = *((char **)t13);
    t16 = 1;
    if (5U == 5U)
        goto LAB37;

LAB38:    t16 = 0;

LAB39:    t1 = t16;
    goto LAB27;

LAB28:    t3 = (t0 + 2152U);
    t7 = *((char **)t3);
    t3 = (t0 + 7115);
    t9 = 1;
    if (5U == 5U)
        goto LAB31;

LAB32:    t9 = 0;

LAB33:    t2 = (!(t9));
    goto LAB30;

LAB31:    t10 = 0;

LAB34:    if (t10 < 5U)
        goto LAB35;
    else
        goto LAB33;

LAB35:    t11 = (t7 + t10);
    t12 = (t3 + t10);
    if (*((unsigned char *)t11) != *((unsigned char *)t12))
        goto LAB32;

LAB36:    t10 = (t10 + 1);
    goto LAB34;

LAB37:    t17 = 0;

LAB40:    if (t17 < 5U)
        goto LAB41;
    else
        goto LAB39;

LAB41:    t13 = (t14 + t17);
    t18 = (t15 + t17);
    if (*((unsigned char *)t13) != *((unsigned char *)t18))
        goto LAB38;

LAB42:    t17 = (t17 + 1);
    goto LAB40;

LAB43:    xsi_set_current_line(67, ng0);
    t11 = (t0 + 7122);
    t14 = (t0 + 4360);
    t15 = (t14 + 56U);
    t18 = *((char **)t15);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t11, 2U);
    xsi_driver_first_trans_fast_port(t14);
    goto LAB3;

LAB45:    t11 = (t0 + 1352U);
    t12 = *((char **)t11);
    t5 = *((unsigned char *)t12);
    t6 = (t5 == (unsigned char)3);
    t1 = t6;
    goto LAB47;

LAB48:    t10 = 0;

LAB51:    if (t10 < 5U)
        goto LAB52;
    else
        goto LAB50;

LAB52:    t3 = (t4 + t10);
    t8 = (t7 + t10);
    if (*((unsigned char *)t3) != *((unsigned char *)t8))
        goto LAB49;

LAB53:    t10 = (t10 + 1);
    goto LAB51;

}


extern void work_a_3515486745_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3515486745_3212880686_p_0,(void *)work_a_3515486745_3212880686_p_1};
	xsi_register_didat("work_a_3515486745_3212880686", "isim/PROCESSOR_PIPELINE_tb_isim_beh.exe.sim/work/a_3515486745_3212880686.didat");
	xsi_register_executes(pe);
}
