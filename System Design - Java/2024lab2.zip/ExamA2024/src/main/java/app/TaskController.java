package app;

import task.Task;
import task.TaskList;

//app.TaskController -> Controller
public class TaskController {
	//xrisimopoiei kai to model kai to view, einai o diamesolavitis kapws
	private TaskList model;
	private TaskUI view;

    public TaskController(TaskList model, TaskUI view) {
    	this.model = model;
        this.view = view;
        model.attachObserver(view);
        view.showTasks(model.getTasks());
    }
    
    //ananewnei ta tasks tou model 
    
    public void addTask(Task newTask) {
        model.addTask(newTask);
    }

    public void setTaskCompleted(int index) {
    	model.setTaskCompleted(index);
    }

    public int getNextTaskNumber() {
        return model.getNextTaskNumber();
    }

}
