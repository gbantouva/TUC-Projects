package app;

import conf.SettingsManager;
import task.TaskList;

public class TaskApp {
	
	
	public static void main(String[] args) {
		//SettingsManager sm = new SettingsManager();
		SettingsManager sm = SettingsManager.getInstance();
		TaskUI taskui = new TaskUI(sm);
		TaskList tlist = new TaskList();
		
		TaskController tctl = new TaskController(tlist, taskui);
		
	}
}
