package app;
import javax.swing.*;

import conf.SettingsManager;
import task.Task;
import task.TaskBuilder;
import task.TaskListObserver;
import util.Helper;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

//app.TaskUI->View
public class TaskUI implements TaskListObserver{
    private JFrame frame;
    private JList<Task> taskList;
    private JButton addButton,doneButton;
    
    private DefaultListModel<Task> listModel;
    private SettingsManager settingsManager;
    private TaskController taskController;
    
    public TaskUI(SettingsManager settingsManager) {
        this.settingsManager = settingsManager;

        frame = new JFrame("Task Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
       

        JPanel panel = new JPanel(new BorderLayout());

        listModel = new DefaultListModel<>();
        taskList = new JList<Task>(listModel);
        taskList.setCellRenderer(new TaskCellRenderer()); // Set custom cell renderer
        
        applySettings(); // Apply settings when the UI is initialized
        
        JScrollPane scrollPane = new JScrollPane(taskList);
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());

        addButton = new JButton("Add Task");

        doneButton = new JButton("Task Done");

        buttonPanel.add(addButton);
        buttonPanel.add(doneButton);
        
        //Xrhsimopoiw Listeners ths Swing
        // me auto to koumpi o xrhsths mporei na prosthesei mia kainouria ergasia
        addButton.addActionListener(e -> addNewTask());
        // me auto to koumpi o xrhsths epilegei mia ergasia kai thn orizei ws completed
        doneButton.addActionListener(e -> setTaskAsCompleted());

        panel.add(buttonPanel, BorderLayout.SOUTH);

        frame.add(panel);
        frame.setVisible(true);
    }
    
    // Pop-up a window to enter title
    public String getNewTaskTitle() {
    	return JOptionPane.showInputDialog(frame, "Enter task title:");
    }
    
    // Pop-up a window to enter descritpion
    public String getNewTaskDescription() {
    	return  JOptionPane.showInputDialog(frame, "Enter task description:");
    }

    // Method to apply settings to the UI
    private void applySettings() {
        String theme = settingsManager.getTheme();
        int fontSize = settingsManager.getFontSize();

        // Apply theme and font size to the UI elements
        frame.getContentPane().setBackground(getColorForTheme(theme));
        taskList.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, fontSize));
    }

    // Helper method to get color based on theme
    private Color getColorForTheme(String theme) {
        switch (theme) {
            case "Dark":
                return Color.DARK_GRAY;
            case "Light":
                return Color.WHITE;
            default:
                return Color.WHITE;
        }
    }
    
    
    // Show in JList a list of tasks
    public void showTasks(List<Task> tasks) {
        listModel.clear();
        for (Task task : tasks) {
            listModel.addElement(task);
        }
    }

    // Get the index of selected task
    public int getSelectedTaskIndex() {
        // Return the index of the selected task in the list
        // Example:
        return taskList.getSelectedIndex();
    }
    

    // Custom cell renderer for Task objects
    private class TaskCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            Task task = (Task) value;

            // Check completion status to set foreground color
            if (task.isCompleted()) {
                label.setForeground(Color.GRAY); // Set color for completed tasks
            } else {
                label.setForeground(Color.BLACK); // Set default color for incomplete tasks
            }

            // Set text based on the task details
            label.setText(task.toString()); // Adjust as needed for task representation

            return label;
        }
    }

    // Add New Task h opoia ekteleitai apo ton Listener
    private void addNewTask() {
    	//rwtaw gia ton titlo ths neas ergasias
        String title = getNewTaskTitle();
        //rwtaw gia thn perigrafi ths neas ergasias
        String description = getNewTaskDescription();
        if (title == null || description == null) 
        	return;
        // proetoimazw ta arguments pou xreiazetai o TaskBuilder
        
        //getNextTaskNumber apo to app.TaskController
        int id = taskController.getNextTaskNumber();
        int priority = Helper.assingPriority(); 
        LocalDateTime creationDate = Helper.getCurrentDateTime();
        //xtizw to task mesw tou TaskBuilder
        TaskBuilder builder = new TaskBuilder(id, title, description, priority, creationDate)
        .isCompleted(false); // optional variable, tin orizo ektos tou constructor ws false afou den einai arxika completed
        Task newTask = builder.build();
        taskController.addTask(newTask);
       }
    
    // thetw thn ergasia ws completed, ekteleitai apo ton listener
    private void setTaskAsCompleted() {
    	int index = getSelectedTaskIndex();
    	if (index != -1) {
    		taskController.setTaskCompleted(index);
           }
       }

	@Override
	public void updateTasks(List<Task> tasks) {
		// TODO Auto-generated method stub
		listModel.clear();
		for (Task task: tasks) {
			listModel.addElement(task);
		}
		
	}
	
}