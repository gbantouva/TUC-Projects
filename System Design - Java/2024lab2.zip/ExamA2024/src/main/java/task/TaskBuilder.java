package task;

import java.time.LocalDateTime;

public class TaskBuilder {
	
	private int id;
    private String title;
    private String description;
    private int priority;
    private LocalDateTime creationDate;
    private boolean completed;
   
    // constructor ths Task
    public TaskBuilder(int id, String title,String description, int priority, LocalDateTime creationDate) {
    	this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.creationDate = creationDate;
        this.completed = false;
    }
    
    // because isCompleted is optional
    public TaskBuilder isCompleted(boolean completed){
        this.completed = completed;
        return this;
    }
    
    // builder design pattern
    public Task build(){
        return new Task(this);
    }
    // Getters gia tis ypoloipes metavlites
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }
 
    public String getDescription() {
        return description;
    }

    public int getPriority() {
        return priority;
    }

    public LocalDateTime getCreationDate() {
        return creationDate;
    }
    
}
