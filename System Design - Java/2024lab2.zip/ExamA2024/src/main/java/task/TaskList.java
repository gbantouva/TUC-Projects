package task;

import java.util.ArrayList;
import java.util.List;

import dao.DAOFactory;

//kanw extend gia metatropi se Thread
public class TaskList extends Thread{
	private int taskCount=0;
    private List<Task> tasks;
    //Observer motivo task.TaskList -> Model
    private List<TaskListObserver> observers;
    //thread
    private final Object lock = new Object();
    private boolean running = true;

    public TaskList() {
        this.tasks = new ArrayList<>();
        this.observers = new ArrayList<>();
		retrieveTasks();
		//ekkinisi tou nimatos
		this.start();
    }

    private void retrieveTasks() {
    	tasks = DAOFactory.getTaskDAO().getAllTasks();
    }
    
    public List<Task> getTasks() {
        return tasks;
    }
    
    public int getNextTaskNumber() {
        return ++taskCount;
    }

    synchronized public void addTask(Task task) {
        tasks.add(task);
        //notify for any update
        notifyObservers();
        // ksypnaw to thread gia na eleksei gia update
        synchronized (lock) {
           lock.notify();
        }
    }

   synchronized public void deleteTask(Task task) {
        tasks.remove(task);
        notifyObservers();
        //same opws panw
        synchronized (lock) {
           lock.notify(); 
        }
    }
    
    synchronized public void setTaskCompleted(int index) {
    	tasks.get(index).setCompleted();
    	notifyObservers();
    	synchronized (lock) {
           lock.notify(); 
        }
    }
    
    //new methods for Observer
    //attach observer
    public void attachObserver(TaskListObserver observer){
        observers.add(observer);
    }
    //detach observer
    public void detachObserver(TaskListObserver observer){
        observers.remove(observer);
    }
    //notify
    private void notifyObservers(){
    	for(TaskListObserver observer: observers){
    		observer.updateTasks(tasks);
        }
    }
    
    @Override
    public void run() {
        while (running) {
            synchronized (lock) {
                try {
                    lock.wait(); 
                    synchronized (this) {
                        if (tasks.size() > 5) {
                            tasks.removeIf(Task::isCompleted);
                            notifyObservers(); 
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    //running = false;
                    //synchronized (lock) {
                    //    lock.notify(); 
                    //}
                }
            }
        }
    }
        
}
