package task;

import java.util.List;

public interface TaskListObserver {
	void updateTasks(List<Task> tasks);
}
