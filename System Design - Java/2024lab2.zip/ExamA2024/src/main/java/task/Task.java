package task;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Task implements Serializable{
	//Used for serializable
	private static final long serialVersionUID = 1L;
	
	private int id;
    private String title;
    private String description;
    private int priority;
    private LocalDateTime creationDate;
    private boolean completed;
    //ftiaxnw kainourio constructor me attribute ton TaskBuilder kai xrisimopoio ton constructor pou ipirxe stin TaskBuilder
    
    /*
    public Task(int id, String title,String description, int priority, LocalDateTime creationDate) {
    	this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.creationDate = creationDate;
        this.completed = false;
    }
    */
    
    public Task(TaskBuilder taskBuilder){
        this.id = taskBuilder.getId();
        this.title = taskBuilder.getTitle();
        this.description = taskBuilder.getDescription();
        this.priority = taskBuilder.getPriority();
        this.creationDate = taskBuilder.getCreationDate();
        //this.completed = taskBuilder.isCompleted();
      }
    
    public String getTitle() {
        return title;
    }
    
    public int getId() {
		return id;
	}
    
    public String getDescription() {
        return description;
    }
    
    public boolean isCompleted() {
        return completed;
    }
    
    public void setCompleted() {
        this.completed = true;
    }
    
    public LocalDateTime getCreationDate() {
		return creationDate;
	}

	public int getPriority() {
		return priority;
	}

	@Override
    public String toString() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("YY-MM-DD hh:mm"); // Example: 01:30:45 PM

        // Format the LocalTime using the formatter
        String formattedTime = creationDate.format(formatter);
        return "Task "+id+" [" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", created=" + formattedTime +"]";
    }
}

