package servlet;
import javax.servlet.*;
// den mou anagnorizei thn servlet den iksera pws na tin valw 
public class AppListener implements ServletContextListener{

}

