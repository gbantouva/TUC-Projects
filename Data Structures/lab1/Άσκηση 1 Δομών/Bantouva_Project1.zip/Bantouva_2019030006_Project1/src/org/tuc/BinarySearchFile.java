package org.tuc;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * A class implementing the binary search algorithm.
 * Keys can have values from Integer.MIN_VALUE + 1 to Integer.MAX_VALUE, so Integer.MIN_VALUE itself is not a valid key in the array.
 * Based on https://www.geeksforgeeks.org/binary-search/
 * @author sk
 *
 */
public class BinarySearchFile {
	private int key;
	private String file;
	private FileManager manager;
	private int nodeKey;
	byte[] local_buffer = new byte[128];
	ByteArrayInputStream byteStream = new ByteArrayInputStream(local_buffer);
	DataInputStream dataStream = new DataInputStream(byteStream);
	byte[] nodeData = new byte[28];

	/**
	 * Constructor. Given newData must be sorted!
	 * @param newData
	 */
	public BinarySearchFile(int key, String file) {
		this.key = key;
		this.file=file;
		this.manager = new FileManager();
		manager.openFile(this.file);
		
	}
	
	public int search() throws IOException {
		int pages = manager.openFile("methodC");
		return doSearch(0, pages, this.key);
	}	
	
    private int doSearch(int leftIndex, int rightIndex, int key) throws IOException 
    { 
    	if (rightIndex >= leftIndex) { 
	    	int mid = leftIndex + (rightIndex - leftIndex) / 2;
			MultiCounter.increaseCounter(1);
			manager.readBlock(mid);
	    	StringNode[] nodeArray = new StringNode[4];
			for (int l=0;l<4;l++) {
				nodeKey = dataStream.readInt();
				dataStream.read(nodeData);
				nodeArray[l] = new StringNode(nodeKey,nodeData);
			}
			dataStream.reset();
			byteStream.reset();
			StringNode firstNode = nodeArray[0];
			StringNode lastNode = nodeArray[3];
			int firstNodeKey = firstNode.getKey();
			int lastNodeKey = lastNode.getKey();
         
            if (firstNodeKey <= key && lastNodeKey >= key) {
            	manager.closeFile();
            	return mid; 
            	  
            }
              
            if (firstNodeKey > key) 
                return doSearch(leftIndex, mid - 1, key); 
  
            return doSearch(mid + 1, rightIndex, key); 
        } 
  
        return Integer.MIN_VALUE; 
    } 
}
