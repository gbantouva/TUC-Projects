package org.tuc;


/**
 * A class implementing interface Node.
 * Implements the compareTo method of the Comparable interface that Node extends 
 * @author sk
 *
 */
public class StringNode implements Node {
	/**
	 * The key of the node
	 */
	private int key;
	private byte[] data = new byte[28];

	/**
	 * The class constructor
	 * 
	 * @param item the value for the key of the node
	 */


	public StringNode(int nodeKey, byte[] nodeData) {
		// TODO Auto-generated constructor stub
		key = nodeKey;
		data = nodeData;
		
	}
	
	/**
	 * Returns the key of the Node.
	 * 
	 * @return the key
	 */
	public int getKey() {
		return key;
	}
	public byte[] getData() {
		return data;
	}
	@Override
	public int compareTo(Node otherNode) {
		if (this.getKey() == otherNode.getKey())
			return 0; // this == otherNode
		else if (this.getKey() > otherNode.getKey())
			return 1; // this > otherNode
		else
			return -1; // this < otherNode
	}
}
