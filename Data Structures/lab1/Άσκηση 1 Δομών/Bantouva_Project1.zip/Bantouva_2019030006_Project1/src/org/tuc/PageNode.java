package org.tuc;


/**
 * A class implementing interface Node.
 * Implements the compareTo method of the Comparable interface that Node extends 
 * @author sk
 *
 */
public class PageNode implements Node {
	/**
	 * The key of the node
	 */
	private int key;
	private int keyPage;

	/**
	 * The class constructor
	 * 
	 * @param item the value for the key of the node
	 */


	public PageNode(int nodeKey, int keyPage) {
		// TODO Auto-generated constructor stub
		key = nodeKey;
		this.keyPage = keyPage;
		
	}
	
	/**
	 * Returns the key of the Node.
	 * 
	 * @return the key
	 */
	
	public int getKey() {
		return key;
	}
	
	public int getIndex() {
		return keyPage;
	}

	@Override
	public int compareTo(Node otherNode) {
		if (this.getKey() == otherNode.getKey())
			return 0; // this == otherNode
		else if (this.getKey() > otherNode.getKey())
			return 1; // this > otherNode
		else
			return -1; // this < otherNode
	}
}
