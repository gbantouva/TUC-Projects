package org.tuc;

import organization.methods.MethodA;
import organization.methods.MethodB;
import organization.methods.MethodC;
import organization.methods.MethodD;

import java.util.Random;   


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Generate keys[]
		Random r = new Random();
		int[] keys = randomKeys();						// generate random keys
		int[] keysToFind = new int[20];					// allocate memory
		for (int j=0;j<20;j++)
			keysToFind[j] = keys[r.nextInt(10000)];		// generate 20 random keys to search for
		
		// Method A
		MethodA a = new MethodA();
		a.writeFile(keys);
		for (int j=0;j<20;j++)
			a.findkey(keysToFind[j]);
		System.out.println("A METHOD:");
		System.out.println("Disk Accesses: " + MultiCounter.getCount(1));
		System.out.println("Average disk accesses: " + (MultiCounter.getCount(1)/20));
		MultiCounter.resetCounter(1);									// Reset counters
		MultiCounter.resetCounter(2);
		
		// Method B
		MethodB b = new MethodB();
		b.writeFile(keys);
		for(int j=0;j<20;j++) {
			b.findkey(keysToFind[j]);
		}
		System.out.println("\nB METHOD:");
		System.out.println("Disk Accesses: " + MultiCounter.getCount(1));
		System.out.println("Average disk accesses: "+ (MultiCounter.getCount(1)/20));
		MultiCounter.resetCounter(1);
		MultiCounter.resetCounter(2);
		MultiCounter.resetCounter(3);
		
		
		// Method C
		MethodC c = new MethodC();
		c.sortFile(keys);
		for(int j=0;j<20;j++) {
			c.findkey(keysToFind[j]);
		}
		System.out.println("\nC METHOD:");
		System.out.println("Sorting reads:"+MultiCounter.getCount(3)+" writes: "+MultiCounter.getCount(4));
		System.out.println("Disk Accesses: " + MultiCounter.getCount(1));
		System.out.println("Average disk accesses: "+ (MultiCounter.getCount(1)/20));
		MultiCounter.resetCounter(1);
		MultiCounter.resetCounter(2);
		MultiCounter.resetCounter(3);
		
		
		// Method D
		MethodD d = new MethodD();
		d.sortFile(keys);
		for(int j=0;j<20;j++) {
			d.findkey(keysToFind[j]);
		}
		System.out.println("\nD METHOD:");
		System.out.println("Disk Accesses: " + MultiCounter.getCount(1));
		System.out.println("Average disk accesses: "+ (MultiCounter.getCount(1)/20));
		MultiCounter.resetCounter(1);
		MultiCounter.resetCounter(2);
		
	}

	
	public static int[] randomKeys() {
		int START_INT = 1;
		int END_INT = 1000001;
		int NO_OF_ELEMENTS = 10000;
		java.util.Random randomGenerator = new java.util.Random();
		int[] randomInts = randomGenerator.ints(START_INT, END_INT).distinct().limit(NO_OF_ELEMENTS).toArray();
		return randomInts;
	}
	
}
