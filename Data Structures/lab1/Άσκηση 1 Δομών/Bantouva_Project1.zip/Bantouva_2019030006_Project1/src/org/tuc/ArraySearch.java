package org.tuc;

import java.util.Random;

/**
 * A class searching sequentially in an array of Nodes based on a int key.
 * Includes functionality to count number of statements and iterations for each search.
 * @author sk
 *
 */
public class ArraySearch implements SearchDataStructure {
	private Node data[];
	
	/**
	 * Constructor. 
	 * @param newData
	 */
	public ArraySearch(Node newData[]) {
		this.data = newData;
	}
	
	@Override
	public Node search(int key) {
		if (data == null) {
			return null;
		}
		int arrayIndex = 0;
		for (arrayIndex=0;arrayIndex < data.length; arrayIndex++) {
			if (data[arrayIndex].getKey() == key) {
				return data[arrayIndex];
			}
		}
		return null;
	}

	// START TODO: it seams that methods getRandomExistingKey and getRandomNonExistingKey are exactly the same
	// as used in BinarySearch. Should add them to an abstract superclass of both classes
	@Override
	public int getRandomExistingKey() {
		Random random = new Random();
		return data[random.nextInt(data.length)].getKey();
	}
	
	@Override
	public int getRandomNonExistingKey(int maxIntNumber, int minIntNumber) {
		// generate random keys in valid range until we find one that does not exist 
		Node found = null;
		Random random = new Random();
		int keyToSearch;
		do {
			keyToSearch = random.nextInt(maxIntNumber-minIntNumber) + minIntNumber;
			found = this.search(keyToSearch);
		} while (found != null);
		
		return keyToSearch;
	} 
	// END TODO
}
