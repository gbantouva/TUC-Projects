package organization.methods;

import java.io.IOException;

public class MethodD {
	
		public int sortFile(int [] keys) {
			return 1;
		}
		
		public int findkey(int key) {
			return 1;
		}
	
	// Method to get a random String of length "length"
		static String getAlphaNumericString(int length) { 
			// chose a Character random from this String 
			String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"+ "0123456789" + "abcdefghijklmnopqrstuvxyz"; 
			// create StringBuffer size of AlphaNumericString 
			StringBuilder sb = new StringBuilder(length); 
			for (int i = 0; i < length; i++) { 
			    // generate a random number between 
			    // 0 to AlphaNumericString variable length 
			    int index = (int)(AlphaNumericString.length() * Math.random()); 
			    // add Character one by one in end of sb 
			    sb.append(AlphaNumericString.charAt(index)); 
			} 
			return sb.toString(); 
		} 

}
