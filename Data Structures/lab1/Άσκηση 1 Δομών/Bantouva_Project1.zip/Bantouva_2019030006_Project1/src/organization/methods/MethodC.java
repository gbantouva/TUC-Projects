package organization.methods;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;

import org.tuc.BinarySearch;
import org.tuc.BinarySearchFile;
import org.tuc.FileManager;
import org.tuc.MultiCounter;
import org.tuc.StringNode;

public class MethodC {
	
	final int rec_size=32;
	final int rec_number=4;
		
		public int sortFile(int[] keys) {
			FileManager manager = new FileManager();
			byte[] local_buffer = new byte[128];
			ByteArrayInputStream byteStream = new ByteArrayInputStream(local_buffer);
			DataInputStream dataStream = new DataInputStream(byteStream);
			StringNode[] nodes = new StringNode[keys.length];
			int nodeKey;
			try {
				byte[] nodeData = new byte[28];
				int pages = manager.openFile("methodA");
				for (int i=1; i< pages; i++) {
					MultiCounter.increaseCounter(3);
					manager.readBlock(i);
					for (int l=0;l<4;l++) {
						nodeKey = dataStream.readInt();
						dataStream.read(nodeData);
						nodes[4*(i-1)+l] = new StringNode(nodeKey,nodeData);
					}
					dataStream.reset();
				}
				manager.closeFile();
				Arrays.sort(nodes);
				manager.openFile("methodC");
				ByteArrayOutputStream byteOutStream = new ByteArrayOutputStream(128);
				DataOutputStream dataOutStream = new DataOutputStream(byteOutStream);
				for (int i=0; i< nodes.length; i+=4) {
					for (int l=0; l<4; l++) {
						dataOutStream.writeInt(nodes[i+l].getKey());
						byteOutStream.write(nodes[i+l].getData(),0,28);
					}
					manager.setBuffer(byteOutStream.toByteArray());
					manager.writeBlock((i+4)/4);							// i ?
					MultiCounter.increaseCounter(4);
					dataOutStream.flush();
					byteOutStream.reset();
				}
				manager.closeFile();
				return 1;
			} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return 0;
			}
		}
		
		public int findkey(int key) {
			FileManager manager = new FileManager();
			
			try {
				int nodeKey;
				byte[] nodeData = new byte[28];
				BinarySearchFile binSearch = new BinarySearchFile(key,"methodC");
				int page = binSearch.search();
				//binary search file
				manager.openFile("methodC");
				MultiCounter.increaseCounter(1);
				manager.readBlock(page);
				byte[] local_buffer = new byte[128];
				local_buffer= manager.getBuffer();
				ByteArrayInputStream byteStream = new ByteArrayInputStream(local_buffer);
				DataInputStream dataStream = new DataInputStream(byteStream);
				
				StringNode[] nodeArray = new StringNode[4];
				for (int l=0;l<4;l++) {
					nodeKey = dataStream.readInt();
					dataStream.read(nodeData);
					nodeArray[l] = new StringNode(nodeKey,nodeData);
				}
				BinarySearch b = new BinarySearch(nodeArray);
				if (b.search(key)!=null) {
					MultiCounter.increaseCounter(2);
					manager.closeFile();
					return 1;
				}
				manager.closeFile();
				return 0;
				
			} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					return 0;
			}
		}
		static String getAlphaNumericString(int length) { 
			// chose a Character random from this String 
			String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"+ "0123456789" + "abcdefghijklmnopqrstuvxyz"; 
			// create StringBuffer size of AlphaNumericString 
			StringBuilder sb = new StringBuilder(length); 
			for (int i = 0; i < length; i++) { 
			    // generate a random number between 
			    // 0 to AlphaNumericString variable length 
			    int index = (int)(AlphaNumericString.length() * Math.random()); 
			    // add Character one by one in end of sb 
			    sb.append(AlphaNumericString.charAt(index)); 
			} 
			return sb.toString(); 
		} 
		
		
	}

