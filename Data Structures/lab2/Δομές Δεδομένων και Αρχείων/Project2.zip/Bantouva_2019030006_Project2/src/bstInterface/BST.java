package bstInterface;

/**
 * Interface BST. Implemented by BST and TBST.
 * @author georg
 *
 */
public interface BST {
	
	/**
	 * This method inserts a certain key.
	 * @param key the key to insert.
	 */
	public void insert(int key);
	
	
	/**
	 * This method searches for a certain key.
	 * @param root the root of tree
	 * @param key the key to search for.
	 * @return the position of the node of the key if it exists.
	 */
	public int search(int root, int key);

	/**
	 * This method insert an array of integers.
	 * @param integers the array of integers to insert.
	 */
	public void insertKeys(int[] integers);

	/**
	 * This method finds the keys between a certain range [kMin, kMax].
	 * @param root root of tree
	 * @param kMin the left limit of the range.
	 * @param kMax the right limit of the range.
	 */
	public void findInRange(int root, int kMin, int kMax);
	
	/**
	 * This method generates a random array of integers to search for, then searches them by calling the function "search".
	 * @param numOfSearches	an integer that indicates how many integers will be searched in the Threaded Binary Search Tree. 
	 */
	public void randomSearches(int numOfSearches);
	
	/**
	 * This method generates a random integer, then creates the range the user asked for and finally calls "findInRange" method to search within this range. 
	 * @param range	an integer that indicates the range to search within
	 * @param numOfSearches an integer that indicates the number of searches to be executed
	 */
	public void rangeRandomSearching(int range, int numOfSearches);
	
}
