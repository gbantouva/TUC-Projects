package searchTrees;

import mainPackage.MultiCounter;

import java.util.Random;

import bstInterface.BST;

/**
 * Class to implement a Binary Search Tree.  It implements the interface BST.
 */

public class BinarySearchTree implements BST{
	
	/**
	 * This variable represents an Nx3 array of integers. It contains the info, the position of the left 
	 * and the right subtree of each element of the Binary Search Tree.
	 */
	int[][] tree;
	
	/**
	 * This variable represents an integer which shows the first empty line. It is a pointer of the stack that contains the first avail position.
	 */
	private int avail;							
	
	/**
	 * This variable represents an integer that shows which line is the root of the Binary Search Tree.
	 */
	private int root;							
	
	/**
	 * This variable represents an integer that shows the size of the Binary Search Tree.
	 */
	private int tree_size;		

	/**
	 * A constructor of BinarySearchTree class.
	 * This Binary Search Tree consists at the most of as many elements as the given parameter's value.
	 *  
	 * @param maxSize an integer whose value determines the maximum number of nodes of the Binary Search Tree.
	 */
	public BinarySearchTree(int maxSize) {
		tree_size = maxSize;
		tree = new int [tree_size][3];					// initializiation of the Binary Search Tree (BST)
		avail = 0;										// first available position is 0
		root = -1;										// because there is no root when the BST is created
		// initializiaztion of the stack
		for(int i=0; i < tree_size-1; i++) {
			setRight(i,i+1);
		}
		setRight(tree_size-1,-1);						// the last node (right) is null (-1)
	} 
	
	/**
	 * This method inserts the elements of the array - parameter in the Binary Search Tree one by one, by calling "insert" function.
	 * @param integers an array of integers to be inserted in the Binary Search Tree.
	 */
	public void insertKeys(int[] integers) {
		for(int i=0; i<integers.length; i++) {
			insert(integers[i]);		// call insert method
		}
		
	}
	
	/** 
	 * This method inserts a certain key, by calling the recursive function "insertRec".
	 * @param key a certain key to insert.
	 */
	public void insert(int key) {
         root = insertRec(root, key);
    }
	
	// source : https://www.geeksforgeeks.org/binary-search-tree-set-1-search-and-insertion/

	/**
	 * This method finds the position to place the key by crossing the tree recursively. 
	 * @param root the root of the tree
	 * @param key the key for insertion
	 * @return root
	 */
	private int insertRec(int root, int key) {
		/* If the tree is empty,   return a new node */
		if (MultiCounter.increaseCounter(1) && root == -1)
		{
			int position = getNode();
			setKey(position,key);
			resetLeftRight(position);//
			MultiCounter.increaseCounter(1,4);								// increase counter by 4 times because of 4 assignments
			//root = new Node(key);
			return position;
		}
		/* Otherwise, cross the tree */
		if (MultiCounter.increaseCounter(1) && key < getKey(root)) {
			setLeft(root,insertRec(getLeft(root), key));
			MultiCounter.increaseCounter(1,3); // increases the counter 2 times for the assignments of the recursive call and 1 time for the assignment setLeft
		}
			//root.left = insertRec(root.left, key);
		else if (MultiCounter.increaseCounter(1) && key > getKey(root)) {
			setRight(root,insertRec(getRight(root), key)); // root.right = insertRec(root.right, key);
			MultiCounter.increaseCounter(1,3); // increases the counter 2 times for the assignments of the recursive call and 1 time for the assignment setRight
		}
		/* return the unchanged root value */
		return root;
	}

	/**
	 * This method generates a random array of integers to search for, then searches them by calling the function "search".
	 * @param numOfSearches	an integer that indicates how many integers will be searched in the BST. 
	 */
	public void randomSearches(int numOfSearches) {
		MultiCounter.resetCounter(2);										// reinitialization of counter
		Random random = new Random ();
		int numbers[] = new int[numOfSearches];								// create an array with size == numOfSearches
		for (int j=0; j<numOfSearches;j++) {
			numbers[j] = random.nextInt(1000000-1);							// generate a random integer between 1 and 100000
		}
		for(int i=0; i<numOfSearches; i++) {
			search(root,numbers[i]);
		}
		System.out.println("Average number of comparisons per random search: " + MultiCounter.getCount(2)/numOfSearches);
	}
	
	/**
	 * This method generates a random integer, then creates the range the user asked for and finally calls "findInRange" method to search within this range. 
	 * @param range	an integer that indicates the range to search within
	 * @param numOfSearches an integer that indicates the number of searches to be executed
	 */
	public void rangeRandomSearching(int range, int numOfSearches) {
		MultiCounter.resetCounter(3);
		Random randomGenerator = new Random();
		int kMin = 0;
		int kMax = 0;
		System.out.println("Range of random searches : " + range);
		
		for(int i=0; i<numOfSearches; i++) {
			kMin = randomGenerator.nextInt(1000000-range)+1;
			kMax = kMin + range;
			MultiCounter.increaseCounter(3,3);
			findInRange(root,kMin, kMax);
		}
		System.out.println("Average number of comparisons per random search in a certain range: " + MultiCounter.getCount(3)/numOfSearches);
	
	}
	
	
	/** 
	 * This method is a utility function to search a given key in BinarySearchTree.
	 * @param root the root of the tree
	 * @param key the key to search
	 */
	public int search(int root, int key)
	{
	    // Base Cases: root is null or key is present at root
	    if (MultiCounter.increaseCounter(2) && root==-1 || MultiCounter.increaseCounter(2) && getKey(root)==key )
	        return root;
	 
	    // Key is greater than root's key
	    if (MultiCounter.increaseCounter(2) && getKey(root) < key) {
	    	MultiCounter.increaseCounter(2,2);
	    	return search(getRight(root), key);
	    }
	 
	    // Key is smaller than root's key
	    MultiCounter.increaseCounter(2,2);
	    return search(getLeft(root), key);
	}
		
	
	/**
	 * This method finds the keys of the Binary Search Tree that have value between k1 and k2. 
	 * @param root the root of the Binary Search Tree
	 * @param k1 left limit of range
	 * @param k2 right limit of range
	 */
	 public void findInRange(int root, int k1, int k2) {
	        if (MultiCounter.increaseCounter(3) && root == -1) {					// case: bst is empty
	            return;
	        }
	        
	        if (MultiCounter.increaseCounter(3) && k1 < getKey(root)) {
				MultiCounter.increaseCounter(3,3);
				findInRange(getLeft(root), k1, k2);
	        }
	 
	        if ((MultiCounter.increaseCounter(3) && k1 <= getKey(root) )&& (MultiCounter.increaseCounter(3) && k2 >= getKey(root))) {
	           // found keys
	           // System.out.print(getKey(root) + " ");
	        }
	       
	        if (MultiCounter.increaseCounter(3) && k2 > getKey(root)) {
				MultiCounter.increaseCounter(3,3);
	        	findInRange(getRight(root), k1, k2);
	        }
	    }
	 
	
	/**
	 * Getter - this method returns the next available position or -1 if there is no such.
	 * 
	 * @return an integer that shows in which line the next available position is.
	 */
	public int getAvail() {
		return avail;
	}
	
	/**
	 * Getter - this method returns the root.
	 * @return 	The root or -1 if it is empty
	 */
	public int getRoot() {
		return root;
	}
	
	/**
	 * Getter - this method returns the size of the Binary Search Tree.
	 * @return the size of tree
	 */
	public int getSize() {
		return tree_size;
	}
	
	/**
	 * Gets the next available tree position from the stack (from column right)
	 * @return the next avail position
	 */
	public int getNode() {
		// check the case that there is no available position
		if(MultiCounter.increaseCounter(1) && avail == -1) {
			System.out.println("The tree is full.");
			return -1;
		}
		// store the next available position in a variable
		MultiCounter.increaseCounter(1);
		int pos = avail;
		// move the avail to the next available pos
		MultiCounter.increaseCounter(1);
		avail = getRight(pos);
		return pos;
	}
	
	/** 
	 * This method resets the right and the left field of a certain line of BinarySearchTree.
	 * @param position it shows the line. 
	 */
	private void resetLeftRight(int position) {
		setLeft(position,-1);
		setRight(position,-1);
	}

	/**
	 * Setter - this method sets the key of a certain line of Binary Search Tree with a certain value.
	 * @param index the number of line
	 * @param value	the specific value that will be set
	 */
	private void setKey(int index, int value) {
		tree[index][0]=value;
		
	}
	

	/**
	 * Getter - this method gets the key of a certain line of Binary Search Tree.
	 * @param index	the number of line
	 * @return	the value
	 */
	private int getKey(int index) {
		return tree[index][0];
	}

	/**
	 * Sets the left field of the given line in BST.
	 * @param index the line of the BST
	 * @param value the value that the left column wil get
	 */
	private void setLeft(int index, int value) {
		tree[index][1]=value;
		
	}

	/**
	 * Gets the left field of a certain line in BST.
	 * @param index the line of the BST
	 * @return the left field
	 */
	private int getLeft(int index) {
		return tree[index][1];
	}
	
	/**
	 * Sets the right field of the given line in BST.
	 * @param index the line of the BST
	 * @param value the value that the right column will get
	 */
	private void setRight(int index, int value) {
		tree[index][2]=value;
		
	}
	
	/**
	 * Gets the right field of a certain line in BST.
	 * @param index the line of the BST
	 * @return the right field
	 */
	private int getRight(int index) {
		return tree[index][2];
	}
	
	
}
