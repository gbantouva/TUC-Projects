package searchTrees;

import java.util.Random;
import bstInterface.BST;
import mainPackage.MultiCounter;

/**
 * Class to implement the Threaded Binary Search Tree. It implements the interface BST.
 * @author georg
 *
 */
public class ThreadedBinarySearchTree implements BST {
	
	/**
	 * This variable represents an Nx5 array of integers. It contains the info, the position of the left 
	 * and the right subtree of each element, the leftThread and the rightThread of the Threaded Binary Search tree.
	 */
	private int threaded_tree [][];
	
	/**
	 * This variable represents an integer that shows which line is the root of the Threaded Binary Search Tree.
	 */
	private int root;
	
	/**
	 * This variable represents an integer which shows the first empty line. 
	 */
	private int avail;

	/**
	 * A constructor of ThreadedBinarySearchTree class.
	 * This Threaded Binary Search Tree consists at the most of as many elements as the given parameter's value.
	 *  
	 * @param size an integer whose value determines the maximum number of nodes of the Threaded Binary Search Tree.
	 */
	public ThreadedBinarySearchTree (int size) {
		this.threaded_tree = new int[size][5];
		avail = 0;									// when the tree is created the first available position is 0
		root = -1;									// root is equal to -1 because there is no root when the BST_ARRAY is created
		for(int i=0; i < size; i++) {
			setKey(i,-1);
			setLeft(i,-1);
			setLeftThread(i,0); // 
			setRight(i,i+1);
			setRightThread(i,0); // 
		}
		setRight(size - 1, -1);
	} 

	/**
	 * This method inserts the elements of the parameter in the BST, by calling insert function.
	 * @param integers an array of integers
	 */
	public void insertKeys(int[] integers) {
		for(int i=0; i<integers.length; i++) {
			this.insert(integers[i]); // call insert method
		}
	}

	/** 
	 * This method inserts a certain key, by calling the function "insertMethod".
	 * @param key a certain key to insert.
	 */
	public void insert(int key) {
		MultiCounter.increaseCounter(1,3);
		root=insertMethod(root,key);
	}
	//source: https://www.geeksforgeeks.org/threaded-binary-tree/?ref=rp
	
	/**
	 * This method finds the position to place the key by crossing the tree. 
	 * @param root the root of the tree
	 * @param ikey the key for insertion
	 * @return root
	 */
	private int insertMethod(int root,int ikey) {
		// Searching for a Node with given value
		int ptr = root;
		int par = -1; // Parent of key to be inserted
		MultiCounter.increaseCounter(1, 2);
		while (MultiCounter.increaseCounter(1) && ptr != -1)
		{
			// If key already exists, return
			if (MultiCounter.increaseCounter(1) && ikey == getKey(ptr))
			{
				System.out.printf("Duplicate Key !\n");
				return root;
			}
			par = ptr; // Update parent pointer
			MultiCounter.increaseCounter(1);
			// Moving on left subtree.
			if (MultiCounter.increaseCounter(1) && ikey < getKey(ptr))
			{
				if (MultiCounter.increaseCounter(1) && getLeftThread(ptr) == 0) {
					ptr = getLeft(ptr);
					MultiCounter.increaseCounter(1);}
				else
					break;
			}
			// Moving on right subtree.
			else
			{
				if (MultiCounter.increaseCounter(1) && getRightThread(ptr) == 0) {
					ptr = getRight(ptr);
					MultiCounter.increaseCounter(1);}
				else
					break;
			}
		}

		// Create a new node
		// Node tmp = new Node();
		int tmp = getNode();
		setKey(tmp,ikey);
		setLeftThread(tmp,1);
		setRightThread(tmp,1);
		MultiCounter.increaseCounter(1,4);


		if (MultiCounter.increaseCounter(1) && par == -1)
		{
			root = tmp;
			setLeft(tmp,-1);
			setRight(tmp,-1);
			MultiCounter.increaseCounter(1,3);
		}
		else if (MultiCounter.increaseCounter(1) && ikey < (getKey(par)))
		{
			setLeft(tmp,getLeft(par));
			setRight(tmp,par);
			setLeftThread(par,0);//0 = false
			setLeft(par,tmp);
			MultiCounter.increaseCounter(1,4);
		}
		else
		{
			setLeft(tmp,par);
			setRight(tmp,getRight(par));
			setRightThread(par,0);
			setRight(par,tmp);
			MultiCounter.increaseCounter(1,4);
		}
		//return root;
		return root;
	}
	
	//in c++
	//https://iq.opengenus.org/operations-in-threaded-binary-tree/

	/** 
	 * This method is a utility function to search a given key in ThreadedBinarySearchTree.
	 * @param root the root of the tree
	 * @param key the key to search
	 */
	public int search( int root , int key ) {
		MultiCounter.increaseCounter(2);
		int ptr = root;
		while (MultiCounter.increaseCounter(2) && ptr != -1) {
			if (MultiCounter.increaseCounter(2) && getKey(ptr) == key) {
				// indicating that the element is found then
				return ptr;
			} else if (MultiCounter.increaseCounter(2)&&getKey(ptr) < key) {
				if (MultiCounter.increaseCounter(2)&&getRightThread(ptr) ==1) {
					break;
				}
				// moving to inorder predecessor of the current node
				MultiCounter.increaseCounter(2);
				ptr = getRight(ptr);
			} else {
				if (MultiCounter.increaseCounter(2)&&getLeftThread(ptr) ==1) {
					break;
				}
				// moving to inorder successor of the current node
				MultiCounter.increaseCounter(2);
				ptr = getLeft(ptr);
			}
		}
		// if not found
		return -1;
	}

	/**
	 * This method finds the keys of the Binary Search Tree that have value between kMin and kMax. 
	 * @param root the root of the Binary Search Tree
	 * @param kMin left limit of range
	 * @param kMax right limit of range
	 */
	
	public void findInRange(int root, int kMin, int kMax) {
		if (MultiCounter.increaseCounter(3) && root == -1) // if tree is empty
			return;
		while (MultiCounter.increaseCounter(3) && root != -1) {
			if ((MultiCounter.increaseCounter(3) && getKey(root) >= kMin))
				if (MultiCounter.increaseCounter(3) && getKey(predecessor(root)) <= kMin) 
					break;
			if (MultiCounter.increaseCounter(3) && getKey(root) < kMin) {
				root = getRight(root);
			}
			else {
				root = getLeft(root);
			}
		}
		do {
			root = successor(root);
		} while ((MultiCounter.increaseCounter(3) && getKey(root)<=kMax)&&(MultiCounter.increaseCounter(3) && root!=-1));
		return;
	
	}
	
	/**
	 * Returns the position of the inorder successor 
	 * @param pointer the position in tree
	 * @return position
	 */
	private int successor(int pointer) {
		if (MultiCounter.increaseCounter(3) && getRightThread(pointer)== 1) {
			return getRight(pointer);
		}
		pointer = getRight(pointer);
		while (MultiCounter.increaseCounter(3) && getLeftThread(pointer)==0) {
			MultiCounter.increaseCounter(3);
			pointer = getLeft(pointer); 
		}
		return pointer;
	}
	
	/**
	 * Returns the position of the inorder Predecessor (or the given pointer if inorder predecessor does not exist)
	 * @param pointer the position in tree
	 * @return position
	 */
	private int predecessor(int pointer) {
		if (MultiCounter.increaseCounter(3) && getLeftThread(pointer)==0 && getLeft(pointer)==-1) {
			return pointer;
		} 
		if (MultiCounter.increaseCounter(3) && getLeftThread(pointer)==1){
			if (MultiCounter.increaseCounter(3) && getLeft(pointer)==-1)
				return pointer; 
			return getLeft(pointer);
		}
		pointer= getLeft(pointer);

		while (MultiCounter.increaseCounter(3) && getRightThread(pointer)==0) {
			MultiCounter.increaseCounter(3);
			pointer = getRight(pointer);
		}
		return pointer;
	}
	
	/**
	 * This method generates a random array of integers to search for, then searches them by calling the function "search".
	 * @param numOfSearches	an integer that indicates how many integers will be searched in the Threaded Binary Search Tree. 
	 */
	public void randomSearches(int numOfSearches) {
		MultiCounter.resetCounter(2);										// reinitialization of counter
		Random random = new Random ();
		int numbers[] = new int[numOfSearches];								// create an array with size == numOfSearches
		for (int j=0; j<numOfSearches;j++) {
			numbers[j] = random.nextInt(1000000-1);							// generate a random integer between 1 and 100000
		}
		for(int i=0; i<numOfSearches; i++) {
			this.search(root,numbers[i]);
		}
		System.out.println("Average number of comparisons per random search: " + MultiCounter.getCount(2)/numOfSearches);
	}
	
	/**
	 * This method generates a random integer, then creates the range the user asked for and finally calls "findInRange" method to search within this range. 
	 * @param range	an integer that indicates the range to search within
	 * @param numOfSearches an integer that indicates the number of searches to be executed
	 */
	public void rangeRandomSearching(int range, int numOfSearches) {
		MultiCounter.resetCounter(3);
		Random randomGenerator = new Random();
		int kMin = 0;
		int kMax = 0;
		System.out.println("Range of random searches : " + range);
		
		for(int i=0; i<numOfSearches; i++) {
			kMin = randomGenerator.nextInt(1000000-range)+1;
			kMax = kMin + range;
			this.findInRange(root,kMin, kMax);
		}
		System.out.println("Average number of comparisons per random search in a certain range: " + MultiCounter.getCount(3)/numOfSearches);
	
	}
	
	/**
	 * Gets the next available tree position from the stack (from column right)
	 * @return the next avail tree position
	 */
	public int getNode() {
		// check the case that there is no available position
		if(MultiCounter.increaseCounter(1) && avail == -1) {
			System.out.println("The tree is full");
			return -1;
		}
		// store the next available position in a variable
		MultiCounter.increaseCounter(1);
		int pos = avail;
		// move the avail to the next available pos
		MultiCounter.increaseCounter(1);
		avail = getRight(pos);
		return pos;
	}
	
	/**
	 * Setter - this method sets the key of a certain line of the Threaded Binary Search Tree with a certain value.
	 * @param index the number of line
	 * @param value the specific value that will be set
	 */
	private void setKey(int index, int value) { threaded_tree[index][0]=value; }
	
	/**
	 * Getter - this method gets the key of a certain line of Threaded Binary Search Tree.
	 * @param index	the number of line
	 * @return the value
	 */
	private int getKey(int index) { return threaded_tree[index][0]; }
	
	/**
	 * Sets the left field of the given line in TBST.
	 * @param index the line of the TBST
	 * @param value the value that the left column will get
	 */
	private void setLeft(int index, int value) { threaded_tree[index][1]=value;	}
	
	/**
	 * Gets the left field of a certain line in TBST.
	 * @param index the line of the BST
	 * @return the left field
	 */
	private int getLeft(int index) { return threaded_tree[index][1]; }
	
	/**
	 * Sets the right field of the given line in TBST.
	 * @param index the line of the TBST
	 * @param value the value that the right column will get
	 */
	private void setRight(int index, int value) { threaded_tree[index][2]=value; }
	
	/**
	 * Gets the right field of a certain line in TBST.
	 * @param index the line of the TBST
	 * @return the right field
	 */
	private int getRight(int index) { return threaded_tree[index][2]; }
	
	/**
	 * Sets the left thread of a certain line in TBST.
	 * @param index the line of the TBST
	 * @param value the value that will be set
	 */
	private void setLeftThread(int index, int value) { threaded_tree[index][3]=value; }
	
	/**
	 * Gets the left thread of a certain line of TBST.
	 * @param index the line of the TBST
	 * @return the value of left thread
	 */
	private int getLeftThread(int index) { return threaded_tree[index][3]; }
	
	/**
	 * Sets the right thread of a certain line in TBST.
	 * @param index the line of the TBST.
	 * @param value the value that will be set
	 */
	private void setRightThread(int index, int value) { threaded_tree[index][4]=value; }
	
	/**
	 * Gets the right thread of a certain line of TBST.
	 * @param index the line of the TBST
	 * @return the value of the right thread
	 */
	private int getRightThread(int index) { return threaded_tree[index][4]; }


}





