package mainPackage;

/**
 * A class implementing the binary search algorithm.
 * Keys can have values from Integer.MIN_VALUE + 1 to Integer.MAX_VALUE, so Integer.MIN_VALUE itself is not a valid key in the array.
 * Based on https://www.geeksforgeeks.org/binary-search/
 * @author sk
 *
 */
public class BinarySearch {
	/**
	 * an array of integers
	 */
	private int data[];

	/**
	 * Constructor. Given newData must be sorted!
	 * @param newData an array of int
	 */
	public BinarySearch(int newData[]) {
		this.data = newData;
	}
	
	/**
	 * Given newData must be sorted!
	 * @param newData an array of integers
	 */
	public void setData(int newData[]) {
		this.data = newData;
	}
	
	/**
	 * Searches data array for given key. Returns the key if found, otherwise Integer.MIN_VALUE
	 * @param key the given key to search for
	 * @return the key or Integer.MIN_VALUE if not found
	 */
	public int search(int key) {
		if (data == null) {
			return Integer.MIN_VALUE;
		}
		return doSearch(0, data.length - 1, key);
	}	
	
	/**
	 * Searches data array for given key. Returns the key if found, otherwise Integer.MIN_VALUE
	 * @param leftIndex the left limit 
	 * @param rightIndex the right limit
	 * @param key the key to search for
	 * @return key if found or Integer.MIN_VALUE otherwise
	 */
    private int doSearch(int leftIndex, int rightIndex, int key) 
    { 
        if (MultiCounter.increaseCounter(2)&&rightIndex >= leftIndex) { 
        	MultiCounter.increaseCounter(2);
        	int mid = leftIndex + (rightIndex - leftIndex) / 2; 
  
            // If the element is present at the 
            // middle itself 
            if (MultiCounter.increaseCounter(2)&&data[mid] == key) 
                return mid; 
  
            // If element is smaller than mid, then 
            // it can only be present in left subarray 
            if (MultiCounter.increaseCounter(2)&&data[mid] > key) {
            	MultiCounter.increaseCounter(2,3);
                return doSearch(leftIndex, mid - 1, key); 
            }
            // Else the element can only be present 
            // in right subarray 
            MultiCounter.increaseCounter(2,3);
            return doSearch(mid + 1, rightIndex, key); 
        } 
        // We reach here when element is not present in array. 
        // We return Integer.MIN_VALUE in this case, so the data array can not contain this value!
        return Integer.MIN_VALUE; 
    } 
    
    /**
     * Method to execute range search in the sorted array.
     * @param leftIndex the left limit
     * @param rightIndex the right limit
     * @param startRange the starting point of our range where we will search
     * @param endRange the ending point of our range where we will search
     * @return the key or Integer.MIN_VALUE
     */
    public int rangeSearch(int leftIndex, int rightIndex, int startRange,int endRange) 
    { 
        if (MultiCounter.increaseCounter(3)&& rightIndex >= leftIndex) { 
        	// int limit = rightIndex;
        	int mid = leftIndex + (rightIndex - leftIndex) / 2; 
        	MultiCounter.increaseCounter(3,2);
        	/*
        	if (mid+1>limit) {
        		return Integer.MIN_VALUE;
        	}
        	*/
            if ((MultiCounter.increaseCounter(3) && data[mid] <= startRange ) && (MultiCounter.increaseCounter(2) && data[mid+1] > startRange)) {
              int position = mid;
	          while(MultiCounter.increaseCounter(3) && data[position] <= endRange) {
	        	  position++;
	            //key in range found
	          }
	          return mid; 
            }
            if (MultiCounter.increaseCounter(3) && data[mid] > endRange ) {
            	MultiCounter.increaseCounter(3,3);
                return rangeSearch(leftIndex, mid - 1, startRange,endRange); 
            } else if (MultiCounter.increaseCounter(2) && data[mid] < startRange ) {
	            MultiCounter.increaseCounter(3,3);
	            return rangeSearch(mid + 1, rightIndex, startRange,endRange);
	        }
        }
        // We reach here when element is not present in array. 
        // We return Integer.MIN_VALUE in this case, so the data array can not contain this value!
        return Integer.MIN_VALUE; 
 
    }
}
