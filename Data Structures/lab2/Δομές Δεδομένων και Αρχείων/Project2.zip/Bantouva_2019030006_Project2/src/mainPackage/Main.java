package mainPackage;

import java.util.Arrays;
import java.util.Random;

import searchTrees.BinarySearchTree;
import searchTrees.ThreadedBinarySearchTree;

/**
 * Main Class
 * @author georg
 *
 */
public class Main {
	
	/**
	 * This variable represents the maximum number of tree nodes.
	 */
	final static int maxNodes = 100000;
	
	/**
	 * This variable represents the number of searches to be executed.
	 */
	final static int numOfSearches = 100;
	
	/**
	 * main method of program
	 * @param args auto generated
	 */
	public static void main(String[] args) {
		int[] keys = randomKeys();

		System.out.println("----------------------------------");
		System.out.println("\tBinary Search Tree");
		System.out.println("----------------------------------");
		MultiCounter.resetCounter(1);
		MultiCounter.resetCounter(2);
		MultiCounter.resetCounter(3);
		BinarySearchTree bstArray = new BinarySearchTree(maxNodes);
		bstArray.insertKeys(keys);
		System.out.println("Comparisons for insertion: "+ MultiCounter.getCount(1)/keys.length);
		bstArray.randomSearches(100);
		bstArray.rangeRandomSearching(100,100);
		bstArray.rangeRandomSearching(1000,100);
		
		System.out.println("----------------------------------");
		System.out.println("   Threaded Binary Search Tree");
		System.out.println("----------------------------------");
		MultiCounter.resetCounter(1);
		MultiCounter.resetCounter(2);
		MultiCounter.resetCounter(3);
		ThreadedBinarySearchTree threaded = new ThreadedBinarySearchTree(maxNodes);
		threaded.insertKeys(keys);
		System.out.println("Comparisons for insertion: "+ MultiCounter.getCount(1)/keys.length);
		threaded.randomSearches(100);
		threaded.rangeRandomSearching(100,100);
		bstArray.rangeRandomSearching(1000,100);
	

		System.out.println("----------------------------------");
		System.out.println("\t  Sorted Array");
		System.out.println("----------------------------------");
		MultiCounter.resetCounter(2);
		Arrays.sort(keys);
		BinarySearch binary_search = new BinarySearch(keys);
		Random randomGenerator = new Random();
		for (int i =0; i<100; i++) {
			binary_search.search(randomGenerator.nextInt(1000000));
		}
		System.out.println("Average number of comparisons per random search: " + MultiCounter.getCount(2)/100);
		MultiCounter.resetCounter(3);
		for (int i =0; i<100; i++) {
			int k1 = randomGenerator.nextInt(1000000-100);
			int k2 = k1+100;
			binary_search.rangeSearch(0,maxNodes,k1,k2);
		}
		
		System.out.println("Average number of comparisons per random search in a certain range: " + MultiCounter.getCount(3)/100);
		MultiCounter.resetCounter(3);
		for (int i =0; i<100; i++) {
			int k1 = randomGenerator.nextInt(1000000-1000);
			int k2 = k1+1000;
			binary_search.rangeSearch(0,maxNodes,k1,k2);
		}
		System.out.println("Average number of comparisons per random search in a certain range: " + MultiCounter.getCount(3)/100);
		
	}
	
	/**
	 * Helpful method to generate an array of random integers.
	 * @return the array of random integers
	 */
	public static int[] randomKeys() {
		int START_INT = 1;
		int END_INT = 1000001;
		int NO_OF_ELEMENTS = 100000;
		java.util.Random randomGenerator = new java.util.Random();
		int[] randomInts = randomGenerator.ints(START_INT, END_INT).distinct().limit(NO_OF_ELEMENTS).toArray();
		return randomInts;
	}
   


}

