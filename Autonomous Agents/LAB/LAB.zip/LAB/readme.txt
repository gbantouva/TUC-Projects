# NAO Robot Italian Teaching Assistant

Author: Bantouva Georgia
Date: 14/05/2024

## Setup Instructions:

1. Download and Install Webots: Visit the Webots official website: [webots.org] and follow the instructions to download and install Webots for your operating system.
2. Extract the Project ZIP File.
3. Download Language Packages: Ensure that Italian and English language packages are installed on your system for speech recognition and text-to-speech functionalities.
4. Install Python: If Python is not already installed on your system, download and install it from the official Python website: [python.org]
5. Install pyttsx3 Library: Open a terminal or command prompt and run the following command:
```bash
pip install pyttsx3
```
6. Install speech recognition: Open a terminal or command prompt and run the following command:
```bash
pip install SpeechRecognition
```
7. Run the Project: Open Webots and open the project by navigating to the directory where you extracted the project files. 
8. Interact with the NAO Robot Teaching Assistant: Once the project is running, follow the instructions to interact with the NAO robot teaching assistant and explore its capabilities. 